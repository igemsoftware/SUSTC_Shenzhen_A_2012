//
//  PartsData.h
//  load_xml_to_coredata
//
//  Created by panda on 12-9-3.
//  Copyright (c) 2012年 panda. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface PartsData : NSManagedObject

@property (nonatomic, retain) NSString * author;
@property (nonatomic, retain) NSString * categories;
@property (nonatomic, retain) NSString * creation_date;
@property (nonatomic, retain) NSString * desc;
@property (nonatomic, retain) NSString * in_stock;
@property (nonatomic, retain) NSString * nickname;
@property (nonatomic, retain) NSString * notes;
@property (nonatomic, retain) NSString * part_name;
@property (nonatomic, retain) NSString * part_type;
@property (nonatomic, retain) NSString * results;
@property (nonatomic, retain) NSString * sequence;
@property (nonatomic, retain) NSString * sequence_length;
@property (nonatomic, retain) NSString * sequence_update;
@property (nonatomic, retain) NSString * short_desc;
@property (nonatomic, retain) NSString * source;
@property (nonatomic, retain) NSString * status;
@property (nonatomic, retain) NSString * twins;

@end
