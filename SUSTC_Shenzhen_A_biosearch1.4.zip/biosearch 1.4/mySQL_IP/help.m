//
//  help.m
//  2ndedits
//
//  Created by abc on 12-7-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "help.h"
#import "webpage.h"
#import "MailComposerViewController.h"

@interface help ()

@end

@implementation help

-(void)dealloc
{
    [super dealloc];
    [style release];
    [mytable release];
    [scrollview release];
    [titleview release];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)loadView {
	
	UIView * first=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
	first.backgroundColor=[UIColor whiteColor];
	self.view=first;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    style=[[styleSetting alloc] init];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
    self.navigationItem.title = @"More";
    
    UIImageView *_background = [style getTableImage];//[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"羊皮纸.png"]];
    _background.frame = CGRectMake(0, 0, 320, 460);
    [self.view addSubview:_background];
    
    scrollview=[[UIScrollView alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
    scrollview.contentSize=CGSizeMake(320, 940);
    scrollview.backgroundColor = [UIColor clearColor];
    [self.view addSubview:scrollview];
    
   
    titleview=[[UIWebView alloc] initWithFrame:CGRectMake(0, 0, 320, 330)];
    titleview.backgroundColor=[UIColor clearColor];
    NSString *path = [[NSBundle mainBundle] pathForResource:@"The Registry Help Page" ofType:@"htm"];

    titleview.opaque=NO;
    NSData *data=[NSData dataWithContentsOfFile:path];
    [titleview loadData:data MIMEType:@"text/html" textEncodingName:@"UTF-8" baseURL:nil];
    [scrollview addSubview:titleview];
    

    //mytable=[[UITableView alloc]initWithFrame:CGRectMake(0, 330, 320, 840) style:UITableViewStyleGrouped];
    CGRect tableFrame = self.view.frame;
    tableFrame.size.height = tableFrame.size.height+20;
    tableFrame.origin.y = tableFrame.origin.y+310;
    mytable=[[UITableView alloc] initWithFrame:tableFrame style:UITableViewStyleGrouped];//记号，table
    mytable.backgroundView = nil;
    mytable.delegate=self;
    mytable.dataSource=self;
    mytable.scrollEnabled=NO;
    mytable.backgroundColor = [UIColor clearColor];
    mytable.separatorStyle=UITableViewCellSeparatorStyleNone;
    [scrollview addSubview:mytable];
    
      
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 3;
            break;
        case 1:
            return 3;
            break;
        case 2:
            return 2;
            break;
        default:
            return 0;
            break;
    }
}





-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return @"Learn!";
            break;
        case 1:
            return @"Use!";
            break;
        default:
            return @"Feedback!";
            break;
    }
}
 
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{   
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    if (indexPath.section==0) {
        if (indexPath.row==0) {
            cell.textLabel.text=@"Synthetic biology";
        }
        else if
            (indexPath.row==1) {
            cell.textLabel.text=@"Assembly";
        }
        else {
            cell.textLabel.text=@"Parts";
        }
    }
    else if (indexPath.section==1) {
        if (indexPath.row==0) {
            cell.textLabel.text=@"About the catalog page";
        }
        else if (indexPath.row==1) {
            cell.textLabel.text=@"About the search page";

        }
        else {
            cell.textLabel.text=@"About the database";
        }
    }
    else {
        if (indexPath.row==1) {
            cell.textLabel.text=@"Email us your suggestions";
        }
        if (indexPath.row==0) {
            cell.textLabel.text=@"About us";
        }
    }
    [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    
    
    //cell.textLabel.textColor=[UIColor darkGrayColor];
    cell.textLabel.textColor = [style getCellTextColour];
    cell.textLabel.alpha = 0.8;
    [cell.textLabel setFont:[UIFont fontWithName:@"Helvetica" size:17.0]];
    cell.selectionStyle=[style getCellSelectedStyle];
    cell.backgroundColor=[style getCellBackColour];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 30;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = (UITableViewCell*) [tableView cellForRowAtIndexPath:indexPath];
    cell.selected=NO;
    
    if (indexPath.section==0) {
        if (indexPath.row==0) {
            webpage *synbio=[[webpage alloc]init];
            [synbio searchwebpage:@"Synthetic Biology"];
            [self.navigationController pushViewController:synbio animated:YES];
            [synbio release];
        }
        if (indexPath.row==1) {
            webpage *assembly=[[webpage alloc]init];
            [assembly searchwebpage:@"Assembly"];
            [self.navigationController pushViewController:assembly animated:YES];
            [assembly release];
        }
        if (indexPath.row==2) {
            webpage *partspage=[[webpage alloc]init];
            [partspage searchwebpage:@"Parts"];
            [self.navigationController pushViewController:partspage animated:YES];
            [partspage release];
        }
    }
    if (indexPath.section==1) {
        if (indexPath.row==0) {
            webpage *catalog=[[webpage alloc]init];
            [catalog searchwebpage:@"Catalog"];
            [self.navigationController pushViewController:catalog animated:YES];
            [catalog release];
        }
        if (indexPath.row==1) {
            webpage *search=[[webpage alloc]init];
            [search searchwebpage:@"Searchpage Tutorial"];
            [self.navigationController pushViewController:search animated:YES];
            [search release];
        }
        if (indexPath.row==2) {
            webpage *database=[[webpage alloc]init];
            [database searchwebpage:@"Database Tutorial"];
            [self.navigationController pushViewController:database animated:YES];
            [database release];
        }
    }
    if (indexPath.section==2) {
        if (indexPath.row==1) {
            MailComposerViewController *mail=[[MailComposerViewController alloc]init];
            [self.navigationController pushViewController:mail animated:YES];
            [mail release];
        }
        if (indexPath.row==0) {
            webpage *database=[[webpage alloc]init];
            [database searchwebpage:@"About us"];
            [self.navigationController pushViewController:database animated:YES];
            [database release];
        }

    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
