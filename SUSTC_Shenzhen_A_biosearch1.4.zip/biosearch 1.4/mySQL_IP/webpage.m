//
//  webpage.m
//  mySQL_IP
//
//  Created by apple on 12-7-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "webpage.h"
#import "Catagory.h"

@interface webpage ()

@end

@implementation webpage

@synthesize content,background,searchkey;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}


- (void)loadView {
	CGRect tableFrame = [[UIScreen mainScreen] bounds];
    tableFrame.size.height = tableFrame.size.height-90;
	UIView * first=[[UIView alloc] initWithFrame:tableFrame];
	first.backgroundColor=[UIColor whiteColor];
	self.view=first;
    [first release];

}


-(void)searchwebpage:(NSString *)_searchkey
{
    CGRect tableFrame = self.view.frame;
    tableFrame.size.height = tableFrame.size.height-24;
    content = [[UIWebView alloc] initWithFrame:tableFrame];
    //content=[[UIWebView alloc]initWithFrame:CGRectMake(0, 0, 320, 370)];
    NSString *path = [[NSString alloc] init];
    path = [[NSBundle mainBundle] pathForResource:_searchkey ofType:@"htm"];
    NSData *data=[NSData dataWithContentsOfFile:path];
    [content loadData:data MIMEType:@"text/html" textEncodingName:@"UTF-8" baseURL:nil];
    content.backgroundColor=[UIColor clearColor];
    content.opaque=NO;
    [self.view addSubview:content];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    style=[[styleSetting alloc] init];
    
    UIImageView *_background = [style getTableImage];
    _background.frame = CGRectMake(0, 0, 320, 460);
    [self.view addSubview:_background];
    [_background release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    [style release];
    [content release];
    [background release];
    [searchkey release];
    [style release];
}

-(void)pushback
{
    Catagory *backview=[[Catagory alloc]init];
    [self.navigationController pushViewController:backview animated:YES];
    [backview release];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
