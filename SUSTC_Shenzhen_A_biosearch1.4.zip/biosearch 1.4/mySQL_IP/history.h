//
//  history.h
//  2ndedits
//
//  Created by abc on 12-7-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FavBiobrick.h"
#import "detailpage.h"
#import "styleSetting.h"
#import "MBProgressHUD.h"
#import <CoreData/CoreData.h>

@interface history : UIViewController<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate,MBProgressHUDDelegate,NSFetchedResultsControllerDelegate>
{
    UITableView *historytable;
    NSInteger  rownum;
    NSMutableArray *storeArray;
	FavBiobrick *detailBiobrick;
    //detailpage *detailresults;
	NSArray *favBiobricks;
    //****************************************browse alert************************************************
    
    NSMutableArray *sectionarray;
    NSMutableArray *markarray;
    NSMutableArray *typearray;
    NSMutableArray *descarray;
    UIAlertView *alert;
    NSString *initbrowsetype;
    styleSetting *style;
    UILabel *_titleLabel;
    NSFetchedResultsController *resultController;
    
}

-(void)sectionstyle:(NSString*)browsekey;
@property(nonatomic, retain) NSFetchedResultsController *resultController;
@property(nonatomic,retain) UITableView *historytable;

@end
