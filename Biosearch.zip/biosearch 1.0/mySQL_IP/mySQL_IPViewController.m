//
//  mySQL_IPViewController.m
//  mySQL_IP
//
//  Created by  apple on 11-7-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "mySQL_IPViewController.h"
//#import "MysqlManager.h"
#import "PartsData.h"
#import "detailpage.h"
@implementation mySQL_IPViewController

@synthesize Key;
@synthesize _Nametitle;
@synthesize name;
@synthesize _searchBarPlayContoller;
@synthesize _sentence;
@synthesize resultController;

- (void)dealloc
{
    [_DNA release];
    [style release];
    [_DNAList release];
    [_Nametitle release];
    [_temp_DNA release];
    [_searchBar release];                //本页面上二次搜索的
    [_searchBarPlayContoller release];
    [resultController release];
    [_sentence release];
    [super dealloc];

}

- (void)didReceiveMemoryWarning
{ 
    [super didReceiveMemoryWarning];

}


#pragma mark - View lifecycle

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{  
    
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSearch target:self action:@selector(searchBar:)];
    self.navigationItem.rightBarButtonItem = rightBarButton;
    
    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, 320, 45)];
    [_searchBar setScopeButtonTitles:[NSArray arrayWithObjects:@"df",nil]];
    _searchBar.delegate = self;
    [_searchBar setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [_searchBar sizeToFit];
    
    _searchBarPlayContoller = [[UISearchDisplayController alloc] initWithSearchBar:_searchBar contentsController:self];
	[self set_searchBarPlayContoller:_searchBarPlayContoller];
	[_searchBarPlayContoller setDelegate:self];
	[_searchBarPlayContoller setSearchResultsDataSource:self];
    
    _temp_DNA = [NSMutableArray array];
    
    style=[[styleSetting alloc]init ];
    
   // [self.view addSubview:navbar];
    UIImageView *_background = [style getTableImage];//[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"羊皮纸.png"]];
    _background.frame = CGRectMake(0, 0, 320, 460);
   // [self.view addSubview:_background];
    
    _DNAList = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, 365) style:UITableViewStylePlain];
    [_DNAList setContentOffset:CGPointMake(0, 45)];
    _DNAList.delegate = self;
    _DNAList.dataSource = self;
    _DNAList.backgroundColor = [UIColor clearColor];
   // _DNAList.separatorColor=[style getTableSeperatorColour];//[UIColor whiteColor];
    _DNAList.tableHeaderView = _searchBar;
 //   _DNAList.backgroundView=_background;
  
                
        _DNA = [[NSMutableArray alloc] initWithCapacity:0];
        
        
        if ([[Key substringToIndex:1] compare:@"%"])
        {
            /*_DNA = [mysqlManager query:[NSString stringWithFormat:@"select * from parts4 where part_type like '%@'",Key]];
             */
            _sentence = [[NSMutableString alloc] initWithFormat:@"part_type contains[cd] '%@' ",Key];
           // NSLog(@"_sentence = %@",_sentence);
            
        }
        else {
            
            NSArray *keyWordArray =[Key componentsSeparatedByString:@"&"];
            
            for (int i=0; i<[keyWordArray count]; i++)
            {
                /*NSMutableArray *tempArray= [mysqlManager query:[NSString stringWithFormat:@"select * from parts4 where short_desc like '%@'",[keyWordArray objectAtIndex:i]]];
                
                
                [_DNA addObjectsFromArray:tempArray];
                 */
            
                if (i==0) {
                    _sentence = [[NSMutableString alloc] initWithFormat:@"short_desc contains[cd] '%@' ",[[keyWordArray objectAtIndex:i] stringByReplacingOccurrencesOfString:@"%" withString:@""]];
                }
                else{
                    [_sentence appendFormat:@"or short_desc contains[cd] '%@'",[[keyWordArray objectAtIndex:i] stringByReplacingOccurrencesOfString:@"%" withString:@""]];
                }
                
                
            }
           // NSLog(@"_sentence = %@",_sentence);
            //_DNA = [self processResult:_DNA];
        }
        mySQL_IPAppDelegate *appdelegate = (mySQL_IPAppDelegate*)[[UIApplication sharedApplication] delegate];
        NSManagedObjectContext *managedObjectContext =appdelegate.managedObjectContext;
        NSFetchRequest *request = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"PartsData" inManagedObjectContext:managedObjectContext];
        [request setEntity:entity];
        if ([_sentence length]) {
            NSPredicate *predicate = [NSPredicate predicateWithFormat:_sentence];
            [request setPredicate:predicate];
        }
      //  NSLog(@"%@",_sentence);
        NSSortDescriptor *sortDescriptor1 = [[NSSortDescriptor alloc] initWithKey:@"part_name" ascending:YES];
        NSSortDescriptor *sortDescriptor2 = [[NSSortDescriptor alloc] initWithKey:@"in_stock" ascending:NO];
        NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor2,sortDescriptor1,nil];
    //最后修改！！！！
    [request setPropertiesToFetch:[[NSArray alloc] initWithObjects:@"part_name", nil]];

        [request setSortDescriptors:sortDescriptors];
        [sortDescriptor1 release];
        [sortDescriptor2 release];
        [sortDescriptors release];
        //[NSFetchedResultsController deleteCacheWithName:nil];
        
        NSFetchedResultsController *fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:managedObjectContext sectionNameKeyPath:nil cacheName:_sentence];
        fetchedResultsController.delegate = self;
        NSError *error;
        BOOL success = [fetchedResultsController performFetch:&error];
        if (!success) {
            
        }
        
        self.resultController = fetchedResultsController;
        
        [request release];

        
        [self.view addSubview:_DNAList];
        [_DNA retain];
        [_temp_DNA removeAllObjects];
        [_temp_DNA addObjectsFromArray:_DNA];
        [_temp_DNA retain];
        
        _Nametitle.text = Key;
    
     

    [super viewDidLoad];
    
    
}
-(void)searchBar:(id)sender
{
    _DNAList.frame = CGRectMake(0, 0, 320, 430);
	[_searchBarPlayContoller setActive:YES animated:YES];

}


 -(void)findKey:(NSNotification*) notification
{
    Key = [notification object];//通过这个获取到传递的对象

}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [[self.resultController sections] count];
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    tableView.backgroundView =  [style getTableImage];
    
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell...
    PartsData *apart = [resultController objectAtIndexPath:indexPath];
    cell.textLabel.text = apart.part_name;
    if ([apart.in_stock isEqualToString:@"1"]) {
        NSString *string =@"In stock";
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@,  %@\n%@" ,apart.status,string,apart.short_desc];
    }
    else{
        NSString *string =@"Not in stock";
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@,  %@\n%@" ,apart.status,string,apart.short_desc];
    }
    
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.detailTextLabel.textColor = [UIColor grayColor];
    
    //[cell.detailTextLabel setText:[NSString stringWithFormat:@"%@,  %@\n%@" ,apart.status,apart.short_desc,apart.desc]];
    [cell.detailTextLabel setNumberOfLines:3];
    [cell.detailTextLabel setTextColor:[UIColor darkGrayColor]];
    cell.textLabel.textColor = [style getCellTextColour];
    
    cell.backgroundColor = [style getCellBackColour];
    
    
   // NSLog(@"part_name = %@", apart.part_name);
    //NSLog(@"%@",apart.desc);
    
    
    return cell;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[[self.resultController sections] objectAtIndex:section] numberOfObjects];
}


-(void)viewDidAppear:(BOOL)animated
{

}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = (UITableViewCell*) [tableView cellForRowAtIndexPath:indexPath];
    cell.selected=NO;
    
    MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    HUD.delegate = self;
    HUD.labelText = @"Loading";
    
    [HUD show:YES];
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 0.01 * NSEC_PER_SEC);
    
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        // Do something...
        detailpage* _detailPage = [[detailpage alloc] init];
        _detailPage.detail= [resultController objectAtIndexPath:indexPath];
        
        
        
        
        [self.navigationController pushViewController:_detailPage animated:YES];
        [_detailPage release];
        
        [HUD hide:YES];
    });
}



#pragma mark UISearchDisplayController Delegate Methods

- (void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{
	/*
	 Hide the search bar
	 */
    
    [_DNA removeAllObjects];
    [_DNA addObjectsFromArray:_temp_DNA];

    [_DNAList reloadData];
    
    
	[_DNAList setContentOffset:CGPointMake(0, 45) animated:YES];
    
}

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    //[self searchInSearchBar:searchText];
    
    if (![searchText length]) {
        return;
        
    }
    mySQL_IPAppDelegate *appdelegate = (mySQL_IPAppDelegate*)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext =appdelegate.managedObjectContext;
   // NSLog(@"%@", _sentence);
    //NSLog(@"%@",managedObjectContext);
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"PartsData" inManagedObjectContext:managedObjectContext];
    //NSLog(@"%@",entity);
    
    [request setEntity:entity];
    //NSLog(@"%@", _sentence);
    //NSLog(@"%@", _sentence);
    NSString *string;
    
    if ( ![_sentence length]) {
        string =[NSString stringWithFormat:@"short_desc contains[cd] '%@'",searchText];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:string];
        [request setPredicate:predicate];
        
    }
    else{
        string =[NSString stringWithFormat:@"%@ AND short_desc contains[cd] '%@'",_sentence,searchText];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:string];
        [request setPredicate:predicate];
        
        
    }
   // NSLog(@"string = %@",string);
    //NSLog(@"%@",entity);
    //[request setEntity:entity];
    NSSortDescriptor *sortDescriptor1 = [[NSSortDescriptor alloc] initWithKey:@"part_name" ascending:YES];
    NSSortDescriptor *sortDescriptor2 = [[NSSortDescriptor alloc] initWithKey:@"in_stock" ascending:NO];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor2,sortDescriptor1,nil];
    [request setSortDescriptors:sortDescriptors];
    [sortDescriptor1 release];
    [sortDescriptor2 release];
    [sortDescriptors release];
    //[NSFetchedResultsController deleteCacheWithName:nil];
    
    NSFetchedResultsController *fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:managedObjectContext sectionNameKeyPath:nil cacheName:string];
    fetchedResultsController.delegate = self;
    NSError *error;
    BOOL success = [fetchedResultsController performFetch:&error];
    if (!success) {
        
    }
    
    self.resultController = fetchedResultsController;
    [request release];
    [_DNAList reloadData];
}
- (void)searchDisplayControllerDidBeginSearch:(UISearchDisplayController *)controller
{
    
	[self.searchDisplayController.searchResultsTableView setDelegate:self];
}
-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    mySQL_IPAppDelegate *appdelegate = (mySQL_IPAppDelegate*)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext =appdelegate.managedObjectContext;
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"PartsData" inManagedObjectContext:managedObjectContext];
    [request setEntity:entity];
    if ([_sentence length]) {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:_sentence];
        [request setPredicate:predicate];
    }
    // NSLog(@"%@",_sentence);
    NSSortDescriptor *sortDescriptor1 = [[NSSortDescriptor alloc] initWithKey:@"part_name" ascending:YES];
    NSSortDescriptor *sortDescriptor2 = [[NSSortDescriptor alloc] initWithKey:@"in_stock" ascending:NO];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor2,sortDescriptor1,nil];
    [request setSortDescriptors:sortDescriptors];
    [sortDescriptor1 release];
    [sortDescriptor2 release];
    [sortDescriptors release];
    //[NSFetchedResultsController deleteCacheWithName:nil];
    
    NSFetchedResultsController *fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:managedObjectContext sectionNameKeyPath:nil cacheName:_sentence];
    fetchedResultsController.delegate = self;
    NSError *error;
    BOOL success = [fetchedResultsController performFetch:&error];
    if (!success) {
        
    }
    
    self.resultController = fetchedResultsController;
    //NSLog(@"%d",[[self.resultController sections] count]);
    //NSLog(@"%@",[[[self.resultController sections] objectAtIndex:0] name]);
    //NSLog(@"%@",[[[self.resultController sections] objectAtIndex:1] name]);
    //NSLog(@"%@",[[[self.resultController sections] objectAtIndex:2] name]);
    
    [request release];
    [_DNAList reloadData];
    NSLog(@"***************");
    
}

@end
