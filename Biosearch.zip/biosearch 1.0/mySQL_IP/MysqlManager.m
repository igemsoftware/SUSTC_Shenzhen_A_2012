//
//  MysqlManager.m
//  mySQL_IP
//
//  Created by  apple on 11-7-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "MysqlManager.h"
//#import "mysql.h"

@implementation MysqlManager

-(id)init
{
    [super init];
    return self;
}

/*-(void)connectHost:(NSString *)host connectUser:(NSString *)user connectPassword:(NSString *)password connectName:(NSString *)name
{
    
    myconnect = mysql_init(nil);
    myconnect = mysql_real_connect(myconnect,[host UTF8String],[user UTF8String],[password UTF8String],[name UTF8String],MYSQL_PORT,NULL,0);
    
	if(!myconnect)
    {
		printf("error code=%i",mysql_errno(myconnect));
        return;
	}
}

-(NSMutableArray*)query:(NSString *)sql
{
    if(!myconnect)
    {
        return nil;
    }
    NSMutableArray *recordsArray = [[[NSMutableArray alloc] init] autorelease];
    
    mysql_query(myconnect, [sql UTF8String]);
    MYSQL_RES* result = mysql_store_result(myconnect);
    int num_rows = mysql_num_rows(result);
    int num_fields = mysql_num_fields(result);
    
    for(int i=0;i<num_rows;i++)
    {
        MYSQL_ROW row = mysql_fetch_row(result);
        NSMutableArray *recordArr = [[NSMutableArray alloc] init];
        
        for(int j=0;j<num_fields;j++)
        { 
            NSString* value= [NSString stringWithUTF8String:row[j]];
            [recordArr addObject:value];
        }
        
        [recordsArray addObject:recordArr];
        [recordArr release];
    }
    return recordsArray;
}

-(NSMutableArray*)getRecordFields
{
    NSMutableArray *array = [[[NSMutableArray alloc] init] autorelease];
    
    MYSQL_RES* result = mysql_store_result(myconnect);
    MYSQL_FIELD *fields = mysql_fetch_field(result);
    
    int num_fields = mysql_num_fields(result);
    
    for(int j=0;j<num_fields;j++)
    {
        NSString* field= [NSString stringWithUTF8String: fields[j].name];
        [array addObject:field];
    }
    return array;
}

-(void)update:(NSString *)sql
{
    if(myconnect)
    {
        mysql_query(myconnect, [sql UTF8String]);
    }
    else
    {
        return;
    }
}

-(void)remove:(NSString *)sql
{
    if(myconnect)
    {
        mysql_query(myconnect, [sql UTF8String]);
    }
    else
    {
        return;
    }
}

-(void)disconnect
{
    mysql_close(myconnect);
}*/

@end
