//
//  styleSetting.m
//  mySQL_IP
//
//  Created by abc on 12-8-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "styleSetting.h"
#import <SystemConfiguration/SCNetworkReachability.h>
#import <netinet/in.h> 

@interface styleSetting ()

@end

@implementation styleSetting

@synthesize cellSelected;
@synthesize cellBackColour;
@synthesize tableSeperatorColour;
@synthesize tableImage;
@synthesize cellTextColour;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
    
  

}


-(UIColor*)getCellBackColour
{
    cellBackColour=[UIColor clearColor];

    return cellBackColour;
}
-(UIColor*)getCellTextColour
{
    cellTextColour=[UIColor blackColor];
    
    return cellTextColour;
}
-(UIColor*)getTableSeperatorColour
{
    tableSeperatorColour=[UIColor blackColor];

    return tableSeperatorColour;
}
-(UIImageView*)getTableImage
{
    tableImage=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"background.png"]];

    return tableImage;
}
-(UITableViewCellSelectionStyle)getCellSelectedStyle
{
    cellSelected=UITableViewCellSelectionStyleBlue;

    return cellSelected;
}
- (BOOL) connectedToNetwork
{
    // Create zero addy
    struct sockaddr_in zeroAddress;
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.sin_len = sizeof(zeroAddress);
    zeroAddress.sin_family = AF_INET;
    
    // Recover reachability flags
    SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *)&zeroAddress);
    SCNetworkReachabilityFlags flags;
    
    BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
    CFRelease(defaultRouteReachability);
    
    if (!didRetrieveFlags)
    {
        return NO;
    }
    
    BOOL isReachable = flags & kSCNetworkFlagsReachable;
    BOOL needsConnection = flags & kSCNetworkFlagsConnectionRequired;
    BOOL nonWiFi = flags & kSCNetworkReachabilityFlagsTransientConnection;
    
    NSURL *testURL = [NSURL URLWithString:@"http://www.google.com/"];
    NSURLRequest *testRequest = [NSURLRequest requestWithURL:testURL cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:20.0];
    
    NSURLConnection *testConnection = [[NSURLConnection alloc] initWithRequest:testRequest delegate:self];
    
    BOOL testConnectionOk = testConnection ? YES : NO;    
    [testConnection release];
    
    return ((isReachable && !needsConnection) || nonWiFi) ? testConnectionOk : NO;
} 

-(void) showNetworkError
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Network Status", nil)
                                                    message:NSLocalizedString(@"Sorry, part functions of the software require a network connection. Please connect the network and try again.",nil)
                                                   delegate:nil
                                          cancelButtonTitle:nil
                                          otherButtonTitles:NSLocalizedString(@"OK", @"OK"), nil];
    [alert show];
    [alert release];
} 

-(void)dealloc
{
    [cellBackColour release];
    [cellTextColour release];
   // [tableImage release];     将这句话移到了viewdidUnload
    [tableSeperatorColour release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    //[tableImage release];    //这句话是怎么回事？
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
