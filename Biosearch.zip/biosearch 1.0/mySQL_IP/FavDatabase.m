//
//  FavDatabase.m
//  mySQL_IP
//
//  Created by abc on 12-7-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "FavDatabase.h"
#import <PlausibleDatabase/PlausibleDatabase.h>

static PLSqliteDatabase * dbPointer;

@implementation FavDataBase

+ (PLSqliteDatabase *) setup{
	if (dbPointer) {
		return dbPointer;
	}
	
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *realPath = [documentPath stringByAppendingPathComponent:@"favBook.sqlite"];
	NSString *sourcePath = [[NSBundle mainBundle] pathForResource:@"FavBook"ofType:@"sqlite"];
	
	NSFileManager *fileManager = [NSFileManager defaultManager];
	if (![fileManager fileExistsAtPath:realPath]) {
		NSError *error;
		if (![fileManager copyItemAtPath:sourcePath toPath:realPath error:&error]) {
		}
	}
    
	dbPointer = [[PLSqliteDatabase alloc] initWithPath:realPath];
	[dbPointer open];
	return dbPointer;
}

+ (void) close{
	if (dbPointer) {
		[dbPointer close];
		dbPointer = NULL;
	}
}
@end
