//
//  popUpDatePicker.m
//  mySQL_IP
//
//  Created by abc on 12-8-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "popUpDatePicker.h"

@implementation popUpDatePicker
@synthesize selectContentLabel;
@synthesize hiddenButton;
@synthesize datePicker;
@synthesize myActionSheet;
@synthesize _maxDate;
@synthesize _minDate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        // 添加一个标签
		selectContentLabel = [[UILabel alloc] initWithFrame: CGRectMake(0, 0, frame.size.width, frame.size.height)];
		selectContentLabel.textAlignment = UITextAlignmentLeft;
        selectContentLabel.textColor  = [UIColor whiteColor];
		selectContentLabel.backgroundColor = [UIColor clearColor];
        selectContentLabel.text = @"Pick a date";
		[self addSubview:selectContentLabel];
		
		// 添加一个隐藏的按钮
		hiddenButton = [UIButton buttonWithType:UIButtonTypeCustom];
		[hiddenButton setFrame: CGRectMake(0, 0, frame.size.width, frame.size.height)];
		hiddenButton.backgroundColor = [UIColor clearColor];
		[hiddenButton addTarget:self action:@selector(hiddenButtonClicked) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:hiddenButton];

		
		// 添加一个actionsheet
        myActionSheet = [[UIActionSheet alloc] initWithTitle:@"Please pick a date" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"OK" otherButtonTitles:@"1", @"2", @"3", @"4", nil];
        
        
        _minDate = [[NSDate alloc] initWithTimeIntervalSince1970:86640*365*33+86640*160];
        _maxDate = [[NSDate alloc] initWithTimeIntervalSinceNow:0];
        datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 99, 320, 216)];
        datePicker.maximumDate = _maxDate;
        datePicker.minimumDate = _minDate;
        datePicker.datePickerMode = UIDatePickerModeDate;
        datePicker.backgroundColor = [UIColor clearColor];
        
        [myActionSheet addSubview:datePicker];
        
    }
    return self;
}

-(void)hiddenButtonClicked {
	
    [myActionSheet showInView:self.window];
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) //ok的index是0
    {
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        
        [dateFormatter setDateFormat: @"yyyy-MM-dd"];
        
        self.selectContentLabel.text = [dateFormatter stringFromDate:datePicker.date];
    }

    
    if (selectContentLabel.text == @"Pick a start date" || selectContentLabel.text == @"Pick an end date") {
        selectContentLabel.textColor = [UIColor grayColor];
    }
    else {
        selectContentLabel.textColor = [UIColor blackColor];
    }
   
}

-(void)dealloc {
	[super dealloc];
	[selectContentLabel release];
    [myActionSheet release];
    [datePicker release];
    [hiddenButton release];
    [_minDate release];
    [_maxDate release];
}

@end
