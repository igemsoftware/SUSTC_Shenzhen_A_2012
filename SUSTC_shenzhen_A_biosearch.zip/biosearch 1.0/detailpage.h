//
//  detailpage.h
//  mySQL_IP
//
//  Created by abc on 12-8-13.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "experienceWebViewController.h"
#import "FavBiobrick.h"
#import "styleSetting.h"
@class PartsData;
@interface detailpage : UIViewController <UISearchBarDelegate,UITextFieldDelegate,UIAlertViewDelegate>
{
    NSMutableDictionary *_res;
    NSArray *_showFirst;
    NSArray *_names;
    NSArray *outputtitles;
    NSArray* _titles;
    NSString* _part_name;
    NSString *_url;
    NSString *_mrurl;
    NSString *_text;
    UINavigationBar* _navBar;
    FavBiobrick *favBiobrick;
    NSString *initmark;
    NSString *initkey;
    NSString *inittype;
    NSString *initdesc;
    NSMutableArray *_indexPathArray;
    styleSetting *style;
    UIWebView *mainscreen;
    UITextField *additonalmark;
    UIAlertView *alertview;
    PartsData *detail;
}

- (void) openSearch;
//-(void) openSearch:(NSString* )key

//- (void) moreSearch: (NSString* )key;
//2012-8-16 周牧兵同学注释掉了上面一行
  //retain 之前是strong

@property (nonatomic, retain) NSString* _part_name;
@property (nonatomic, retain) PartsData *detail;



@end
