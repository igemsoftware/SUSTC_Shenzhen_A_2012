//
//  Catagory.m
//  mySQL_IP
//
//  Created by 熠琦 蒋 on 12-7-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "Catagory.h"
#import "webpage.h"
#import "mySQL_IPViewController.h"
#import "webpage.h"
#import "DropDownCell.h"
#import "TopAlert.h"
static NSString *kTitleKey = @"title";
static NSString *kViewControllerKey = @"listviewController";
static NSString *pViewControllerKey = @"descripviewController";
static NSString *dViewControllerKey = @"designviewController";


@interface Catagory ()

@end

@implementation Catagory

@synthesize Table1;
@synthesize Table2;
@synthesize Table3;
@synthesize Table4;
@synthesize index;
@synthesize _list;

@synthesize _tlist;
@synthesize _tchassislist;
@synthesize _tfunctionlist;
@synthesize _tparttypelist;
@synthesize _tdevicetypelist;
@synthesize _insert;
@synthesize _iparttypelist;
@synthesize _ichassislist;
@synthesize _ifunctionlist;
@synthesize _idevicetypelist;

@synthesize _dropdown;
@synthesize _dchassislist;
@synthesize _dfunctionlist;
@synthesize _dparttypelist;
@synthesize _ddevicetypelist;

@synthesize _llist;
@synthesize _lchassislist;
@synthesize _lfunctionlist;
@synthesize _lparttypelist;
@synthesize _ldevicetypelist;

@synthesize tutorial;
@synthesize keynum;

-(void )dealloc
{
    
    [super dealloc];
    [Table1 release];
    [_tlist release];
    [_llist release];
    [style release];
    [view1 release];
    [view2 release];
    [view3 release];
    [view4 release];
    [mytable release];
    [style release];
    [tutorial release];
    [Table1 release];
    [Table2 release];
    [Table3 release];
    [Table4 release];
    [_list release];
    [_tlist release];
    [_tchassislist release];
    [_tfunctionlist release];
    [_tparttypelist release];
    [_tdevicetypelist release];
    [_insert release];
    [_iparttypelist release];
    [_ichassislist release];
    [_ifunctionlist release];
    [_idevicetypelist release];
    [_dropdown release];
    [_dchassislist release];
    [_dfunctionlist release];
    [_dparttypelist release];
    [_ddevicetypelist release];
    [_llist release];
    [_lchassislist release];
    [_lfunctionlist release];
    [_lparttypelist release];    
    [_ldevicetypelist release];
    [tutorial release];

}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    style=[[styleSetting alloc] init];
    _list=[[NSArray alloc]initWithObjects:@"list",@"description",@"design", nil];
    
    keynum = 1;
    
    self.navigationItem.title = @"Catalog";
    self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
    
    tutorial=[[UIBarButtonItem alloc]initWithTitle:@"Tutorial" style:UIBarButtonItemStyleBordered target:self action:@selector(showtutorial)];
    [self.navigationItem setRightBarButtonItem:tutorial];
    
    Table1.backgroundView = [style getTableImage];//[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"羊皮纸.png"]];
    Table2.backgroundView = [style getTableImage];//[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"羊皮纸.png"]];
    Table3.backgroundView = [style getTableImage];//[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"羊皮纸.png"]];
    Table4.backgroundView = [style getTableImage];//[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"羊皮纸.png"]];
    Table1.separatorColor = [style getTableSeperatorColour];//[UIColor whiteColor];
    Table2.separatorColor = [style getTableSeperatorColour];//[UIColor whiteColor];
    Table3.separatorColor = [style getTableSeperatorColour];//[UIColor whiteColor];
    Table4.separatorColor = [style getTableSeperatorColour];//[UIColor whiteColor];
    
    _tparttypelist = [[NSMutableArray alloc]initWithObjects:@"Promoter",@"Ribosome Binding Site",@"Protein domains",@"Protein coding sequences",@"Translational units",@"Terminators",@"DNA",@"Plasmid backbones",@"Plasmids",@"Primers",@"Composite parts",  nil];
    
    
    
    _tdevicetypelist = [[NSMutableArray alloc]initWithObjects:@"Protein Generators",@"Reporters",@"Inverters",@"Receivers and senders",@"Measurement devices",  nil];
    
    _tfunctionlist = [[NSMutableArray alloc]initWithObjects:@"Biosynthesis",@"Cell-cell signaling",@"Cell Death",@"Coliroid",@"Conjugation",@"Motility and chemotaxis",@"Odor",@"DNA recombination",@"Viral vectors", nil];
    
    _tchassislist = [[NSMutableArray alloc]initWithObjects:@"Escherichia coli",@"Yeast",@"Bacteriophage T7",@"Bacillus subtilis",nil];//,@"MammoBlocks", nil];
    
    _tlist = _tparttypelist;
    _llist = _lparttypelist;
    _dropdown=[NSMutableArray array];
    _dparttypelist = [NSMutableArray array];
    _dchassislist = [NSMutableArray array];
    _ddevicetypelist = [NSMutableArray array];
    _dfunctionlist = [NSMutableArray array];
    _lparttypelist = [NSMutableArray array];
    _lchassislist = [NSMutableArray array];
    _ldevicetypelist = [NSMutableArray array];
    _lfunctionlist = [NSMutableArray array];
    _idevicetypelist = [NSMutableArray array];
    _ifunctionlist = [NSMutableArray array];
    _ichassislist = [NSMutableArray array];
    _iparttypelist = [NSMutableArray array];
    _insert = [NSMutableArray array];
    
    
    mySQL_IPViewController *promoter;
    promoter = [[mySQL_IPViewController alloc]init];
    promoter.Key = @"% promoter %";
    [promoter.Key stringByReplacingOccurrencesOfString:@"%" withString:@" "];
    //NSLog(@"%@",[promoter.Key stringByReplacingOccurrencesOfString:@"%" withString:@" "]);
    webpage *_promoters=[[webpage alloc]init];
    [_promoters searchwebpage:@"Promoters" ];
    webpage *_dpromoter=[[webpage alloc]init];
    [_dpromoter searchwebpage:@"Design-Promoters"];
    
    
    [self._lparttypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                                    NSLocalizedString(@"Promoter", @""), kTitleKey,
                                    promoter, kViewControllerKey,
                                    _promoters, pViewControllerKey,
                                    _dpromoter, dViewControllerKey,nil]];
    [self._dparttypelist addObject:[NSArray arrayWithObjects:@"", nil]];
    	//[promoter release];
    [self._iparttypelist addObject:[NSArray arrayWithObjects:@"",@"",@"",@"", nil]];
    
    
    mySQL_IPViewController *Ribosome_Binding_Sites;
    Ribosome_Binding_Sites = [[mySQL_IPViewController alloc]init];
    Ribosome_Binding_Sites.Key = @"RBS";
  //  NSLog(@"Ribosome_Binding_Sites %d",[[Ribosome_Binding_Sites.Key substringToIndex:1] compare:@"%"]);
    webpage *_Ribosome=[[webpage alloc]init];
    [_Ribosome searchwebpage:@"Ribosome Binding Site"];
    webpage *_dRibosome=[[webpage alloc]init];
    [_dRibosome searchwebpage:@"Design-RBS"];
    
    [self._lparttypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Ribosome Binding Sites", @""), kTitleKey,Ribosome_Binding_Sites, kViewControllerKey, _Ribosome, pViewControllerKey,_dRibosome, dViewControllerKey,nil]];
    [self._dparttypelist addObject:[NSArray arrayWithObjects:@"", nil]];
    [self._iparttypelist addObject:[NSArray arrayWithObjects:@"",@"",@"",@"", nil]];

    
    
    mySQL_IPViewController *Protein_domains;
    Protein_domains = [[mySQL_IPViewController alloc]init];
    Protein_domains.Key = @"Protein_Domain";
    webpage *_proteindomain=[[webpage alloc]init];
    [_proteindomain searchwebpage:@"Protein Domain"];
    webpage *_dproteindomain=[[webpage alloc]init];
    [_dproteindomain searchwebpage:@"Design-Protein Domain"];
    
    [self._lparttypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"Protein domains", @""), kTitleKey,
Protein_domains, kViewControllerKey, _proteindomain, pViewControllerKey,_dproteindomain, dViewControllerKey,nil]];
    
    [self._dparttypelist addObject:[NSArray arrayWithObjects:@"", nil]];
    [self._iparttypelist addObject:[NSArray arrayWithObjects:@"",@"",@"",@"", nil]];
    
    
    mySQL_IPViewController *Protein_coding_sequences;
    Protein_coding_sequences = [[mySQL_IPViewController alloc]init];
    Protein_coding_sequences.Key = @"Coding";
    webpage *_proteincodingsquence=[[webpage alloc]init];
    [_proteincodingsquence searchwebpage:@"Protein Coding Sequence"];
    webpage *_dprotein=[[webpage alloc]init];
    [_dprotein searchwebpage:@"Design-Protein Coding Sequences"];

    [self._lparttypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"Protein coding sequences", @""), kTitleKey,
Protein_coding_sequences, kViewControllerKey, _proteincodingsquence, pViewControllerKey,_dprotein, dViewControllerKey,nil]];
    
    [self._dparttypelist addObject:[NSArray arrayWithObjects:@"", nil]];
    [self._iparttypelist addObject:[NSArray arrayWithObjects:@"",@"",@"",@"", nil]];


    
    mySQL_IPViewController *Translational_units;
    Translational_units = [[mySQL_IPViewController alloc]init];
    Translational_units.Key = @"Translational_Unit";
    webpage *_translational_units=[[webpage alloc]init];
    [_translational_units searchwebpage:@"Translational Units"];
 
    [self._lparttypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:Translational_units, kViewControllerKey, _translational_units, pViewControllerKey,nil]];
    [self._dparttypelist addObject:[NSArray arrayWithObjects:@"", nil]];
    //[promoter release];
    [self._iparttypelist addObject:[NSArray arrayWithObjects:@"",@"",@"", nil]];
    
    mySQL_IPViewController *Terminators;
    Terminators = [[mySQL_IPViewController alloc]init];
    Terminators.Key = @"Terminator";
    webpage *_terminators=[[webpage alloc]init];
    [_terminators searchwebpage:@"Terminators"];
    webpage *_dterminators=[[webpage alloc]init];
    [_dterminators searchwebpage:@"Design-Terminators"];
 
    [self._lparttypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"Terminator", @""), kTitleKey,
Terminators, kViewControllerKey, _terminators, pViewControllerKey,_dterminators, dViewControllerKey,nil]];
    
    [self._dparttypelist addObject:[NSArray arrayWithObjects:@"", nil]];
    [self._iparttypelist addObject:[NSArray arrayWithObjects:@"",@"",@"",@"", nil]];
    

    
    
    mySQL_IPViewController *DNA;
    DNA = [[mySQL_IPViewController alloc]init];
    DNA.Key = @"DNA";
    webpage *_DNA=[[webpage alloc]init];
    [_DNA searchwebpage:@"DNA"];
 
    [self._lparttypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"DNA", @""), kTitleKey,
DNA, kViewControllerKey, _DNA, pViewControllerKey,nil]];
    [self._dparttypelist addObject:[NSArray arrayWithObjects:@"", nil]];
    [self._iparttypelist addObject:[NSArray arrayWithObjects:@"",@"",@"", nil]];
    
    
    
    
    mySQL_IPViewController *Plasmid_backbones;
    Plasmid_backbones=[[mySQL_IPViewController alloc]init];
    Plasmid_backbones.Key=@"Plasmid_Backbone";
    webpage *_plasmidbackbones=[[webpage alloc]init];
    [_plasmidbackbones searchwebpage:@"Plasmid Backbones"];

    
    [self._lparttypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"Plasmid backbones", @""), kTitleKey,
     Plasmid_backbones, kViewControllerKey, _plasmidbackbones, pViewControllerKey,nil]];
    [self._dparttypelist addObject:[NSArray arrayWithObjects:@"", nil]];
    [self._iparttypelist addObject:[NSArray arrayWithObjects:@"",@"",@"", nil]];
    
    
    
    mySQL_IPViewController *Plasmids;
    Plasmids = [[mySQL_IPViewController alloc]init];
    Plasmids.Key = @"Plasmid";
    webpage *_plasmids=[[webpage alloc]init];
    [_plasmids searchwebpage:@"Plasmids"];

    [self._lparttypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"Plasmids", @""), kTitleKey,
Plasmids, kViewControllerKey, _plasmids, pViewControllerKey,nil]];
    [self._dparttypelist addObject:[NSArray arrayWithObjects:@"", nil]];
    [self._iparttypelist addObject:[NSArray arrayWithObjects:@"",@"",@"", nil]];
    

    
    
    mySQL_IPViewController *Primers;
    Primers = [[mySQL_IPViewController alloc]init];
    Primers.Key = @"Primer";
    webpage *_primers=[[webpage alloc]init];
    [_primers searchwebpage:@"Primers"];
    webpage *_dprimers=[[webpage alloc]init];
    [_dprimers searchwebpage:@"Design-Primers"];
    
    [self._lparttypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"Primers", @""), kTitleKey,
Primers, kViewControllerKey, _primers, pViewControllerKey,_dprimers, dViewControllerKey,nil]];
    [self._dparttypelist addObject:[NSArray arrayWithObjects:@"", nil]];
    [self._iparttypelist addObject:[NSArray arrayWithObjects:@"",@"",@"", @"",nil]];
    
    

    mySQL_IPViewController *Composite_parts ;
    Composite_parts  = [[mySQL_IPViewController alloc]init];
    Composite_parts .Key = @"Composite";
    
    [self._lparttypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Composite parts", @""), kTitleKey,
Composite_parts, kViewControllerKey, nil]];
    [self._dparttypelist addObject:[NSArray arrayWithObjects:@"", nil]];
    [self._iparttypelist addObject:[NSArray arrayWithObjects:@"",@"", nil]];
    
  //第二张表  
    
    mySQL_IPViewController *Protein_Generators;
    Protein_Generators = [[mySQL_IPViewController alloc]init];
    Protein_Generators.Key = @"Generator";
                                       
    [self._ldevicetypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                                      NSLocalizedString(@"Protein Generators", @""), kTitleKey,Protein_Generators,kViewControllerKey, nil]];                               
    [self._ddevicetypelist addObject:[NSArray arrayWithObject:@""]];
    [self._idevicetypelist addObject:[NSArray arrayWithObjects:@"",@"", nil]];
    
    mySQL_IPViewController *Reporters;
    Reporters = [[mySQL_IPViewController alloc]init];
    Reporters.Key = @"Reporter";
     
    [self._ldevicetypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys: NSLocalizedString(@"Reporters", @""), kTitleKey,
Reporters,kViewControllerKey, nil]]; 
    [self._ddevicetypelist addObject:[NSArray arrayWithObject:@""]];
    [self._idevicetypelist addObject:[NSArray arrayWithObjects:@"",@"", nil]];
    
    
    
    mySQL_IPViewController *Inverters;
    Inverters = [[mySQL_IPViewController alloc]init];
    Inverters.Key = @"Inverter";
    
    [self._ldevicetypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Inverters", @""), kTitleKey,Inverters,kViewControllerKey, nil]]; 
    [self._ddevicetypelist addObject:[NSArray arrayWithObject:@""]];
    [self._idevicetypelist addObject:[NSArray arrayWithObjects:@"",@"", nil]];
    
    
    
    mySQL_IPViewController *Receivers_and_senders ;
    Receivers_and_senders  = [[mySQL_IPViewController alloc]init];
    Receivers_and_senders .Key= @"% receiver %&% sender %";
   // NSLog(@"%@",[Receivers_and_senders.Key componentsSeparatedByString:@"&"]);

    [self._ldevicetypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Receivers and senders", @""), kTitleKey,Receivers_and_senders,kViewControllerKey, nil]]; 
    [self._ddevicetypelist addObject:[NSArray arrayWithObject:@""]];
    [self._idevicetypelist addObject:[NSArray arrayWithObjects:@"",@"", nil]];    
    
    mySQL_IPViewController *Measurement_devices ;
    Measurement_devices = [[mySQL_IPViewController alloc]init];
    Measurement_devices.Key= @"Measurement";
 
    [self._ldevicetypelist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                     NSLocalizedString(@"Measurement devices ", @""), kTitleKey,
Measurement_devices,kViewControllerKey, nil]]; 
    [self._ddevicetypelist addObject:[NSArray arrayWithObject:@""]];
    [self._idevicetypelist addObject:[NSArray arrayWithObjects:@"",@"", nil]];    
//第三张表
    
    mySQL_IPViewController *Biosynthesis;
    Biosynthesis = [[mySQL_IPViewController alloc]init];
    Biosynthesis.Key = @"% Biosynthesis %";
    webpage *_biosynthesis=[[webpage alloc]init];
    [_biosynthesis searchwebpage:@"Biosynthesis"];
  
    [self._lfunctionlist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Biosynthesis", @""), kTitleKey,
Biosynthesis,kViewControllerKey,_biosynthesis,pViewControllerKey, nil]]; 
    [self._dfunctionlist addObject:[NSArray arrayWithObject:@""]];
    [self._ifunctionlist addObject:[NSArray arrayWithObjects:@"",@"",@"", nil]];
    
    
    
    
    mySQL_IPViewController *Cell_cell_signaling_and_quorum_sensing;
    Cell_cell_signaling_and_quorum_sensing = [[mySQL_IPViewController alloc]init];
    Cell_cell_signaling_and_quorum_sensing.Key = @"Signalling";
    
    [self._lfunctionlist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Cell-cell signaling", @""), kTitleKey,Cell_cell_signaling_and_quorum_sensing,kViewControllerKey, nil]]; 
    [self._dfunctionlist addObject:[NSArray arrayWithObject:@""]];
    [self._ifunctionlist addObject:[NSArray arrayWithObjects:@"",@"", nil]];
    
    
    mySQL_IPViewController *Cell_death;
    Cell_death = [[mySQL_IPViewController alloc]init];
    Cell_death.Key = @"%cell death%";
     
    [self._lfunctionlist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Cell Death", @""),
                                    kTitleKey,
Cell_death,kViewControllerKey, nil]]; 
    [self._dfunctionlist addObject:[NSArray arrayWithObject:@""]];
    [self._ifunctionlist addObject:[NSArray arrayWithObjects:@"",@"", nil]];
    
    mySQL_IPViewController *Coliroid;
    Coliroid = [[mySQL_IPViewController alloc]init];
    Coliroid.Key = @"%Coliroid%";
  
    
    [self._lfunctionlist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"Coliroid", @""), kTitleKey,
Coliroid,kViewControllerKey, nil]]; 
    [self._dfunctionlist addObject:[NSArray arrayWithObject:@""]];
    [self._ifunctionlist addObject:[NSArray arrayWithObjects:@"",@"", nil]];
    
    
    
    mySQL_IPViewController *Conjugation;
    Conjugation = [[mySQL_IPViewController alloc]init];
    Conjugation.Key = @"Conjugation";
    webpage *_conjugation=[[webpage alloc]init];
    [_conjugation searchwebpage:@"Conjugation"];
    
    [self._lfunctionlist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"Conjugation", @""), kTitleKey,
Conjugation,kViewControllerKey,_conjugation,pViewControllerKey, nil]]; 
    [self._dfunctionlist addObject:[NSArray arrayWithObject:@""]];
    [self._ifunctionlist addObject:[NSArray arrayWithObjects:@"",@"", @"",nil]];
    
    
    mySQL_IPViewController *Motility_and_chemotaxis;
    Motility_and_chemotaxis = [[mySQL_IPViewController alloc]init];
    Motility_and_chemotaxis.Key = @"% Motility %&% chemotaxis %";
        
    [self._lfunctionlist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"Motility and chemotaxis", @""), kTitleKey,
Motility_and_chemotaxis,kViewControllerKey, nil]]; 
    [self._dfunctionlist addObject:[NSArray arrayWithObject:@""]];
    [self._ifunctionlist addObject:[NSArray arrayWithObjects:@"",@"", nil]];
    
    mySQL_IPViewController *Odor;
    Odor = [[mySQL_IPViewController alloc]init];
    Odor.Key = @"% Odor %";
    
    [self._lfunctionlist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"Odor", @""), kTitleKey,
Odor,kViewControllerKey, nil]]; 
    [self._dfunctionlist addObject:[NSArray arrayWithObject:@""]];
    [self._ifunctionlist addObject:[NSArray arrayWithObjects:@"",@"", nil]];
    
    
    mySQL_IPViewController *DNA_recombination;
    DNA_recombination = [[mySQL_IPViewController alloc]init];
    DNA_recombination.Key = @"%recombination%";
     
    [self._lfunctionlist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"DNA recombination", @""), kTitleKey,
DNA_recombination,kViewControllerKey, nil]]; 
    [self._dfunctionlist addObject:[NSArray arrayWithObject:@""]];
    [self._ifunctionlist addObject:[NSArray arrayWithObjects:@"",@"", nil]];
    
    mySQL_IPViewController *Viral_vectors;
    Viral_vectors = [[mySQL_IPViewController alloc]init];
    Viral_vectors.Key= @"%Viral%&vector%";
        
    [self._lfunctionlist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                   NSLocalizedString(@"Viral vectors", @""), kTitleKey,
Viral_vectors,kViewControllerKey, nil]]; 
    [self._dfunctionlist addObject:[NSArray arrayWithObject:@""]];
    [self._ifunctionlist addObject:[NSArray arrayWithObjects:@"",@"", nil]];
    
    
  //第四张表 
    
    mySQL_IPViewController *Escherichia_coli;
    Escherichia_coli = [[mySQL_IPViewController alloc]init];
    Escherichia_coli.Key = @"%Coli%";
    webpage *_e_coli=[[webpage alloc]init];
    [_e_coli searchwebpage:@"Escherichia Coli"];

    [self._lchassislist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                  NSLocalizedString(@"Escherichia coli", @""), kTitleKey,
Escherichia_coli,kViewControllerKey,_e_coli,pViewControllerKey, nil]]; 
    [self._dchassislist addObject:[NSArray arrayWithObject:@""]];
    [self._ichassislist addObject:[NSArray arrayWithObjects:@"",@"",@"", nil]];
    
    mySQL_IPViewController *Yeast;
    Yeast = [[mySQL_IPViewController alloc]init];
    Yeast.Key = @"% yeast %";
    webpage *_yeast=[[webpage alloc]init];
    [_yeast searchwebpage:@"Yeast"];

    [self._lchassislist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                  NSLocalizedString(@"Yeast", @""), kTitleKey,
Yeast,kViewControllerKey,_yeast,pViewControllerKey, nil]];
    [self._dchassislist addObject:[NSArray arrayWithObject:@""]];
    [self._ichassislist addObject:[NSArray arrayWithObjects:@"",@"",@"", nil]];
    
    
    mySQL_IPViewController *Bacteriophage_T7;
    Bacteriophage_T7 = [[mySQL_IPViewController alloc]init];
    Bacteriophage_T7.Key = @"T7";
    webpage *_B_T7=[[webpage alloc]init];
    [_B_T7 searchwebpage:@"Bacteriophage T7"];

    [self._lchassislist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                  NSLocalizedString(@"Bacteriophage T7", @""), kTitleKey,
Bacteriophage_T7,kViewControllerKey,_B_T7,pViewControllerKey, nil]];
    [self._dchassislist addObject:[NSArray arrayWithObject:@""]];
    [self._ichassislist addObject:[NSArray arrayWithObjects:@"",@"",@"", nil]];
  
    
    
    mySQL_IPViewController *Bacillus_subtilis;
    Bacillus_subtilis = [[mySQL_IPViewController alloc]init];
    Bacillus_subtilis.Key = @"%Bacillus%&%subtilis%";

    [self._lchassislist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                  NSLocalizedString(@"Bacillus subtilis", @""), kTitleKey,
Bacillus_subtilis,kViewControllerKey, nil]];
    
    [self._dchassislist addObject:[NSArray arrayWithObject:@""]];
    [self._ichassislist addObject:[NSArray arrayWithObjects:@"",@"", nil]];

    
    mySQL_IPViewController *MammoBlocks;
    MammoBlocks = [[mySQL_IPViewController alloc]init];
    MammoBlocks.Key = @"%block%";

    
   // [self._lchassislist addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:                                  NSLocalizedString(@"MammoBlocks", @""), kTitleKey,
//MammoBlocks,kViewControllerKey, nil]];
   // [self._dchassislist addObject:[NSArray arrayWithObject:@""]];
   // [self._ichassislist addObject:[NSArray arrayWithObjects:@"",@"", nil]];

    
    _llist = _lparttypelist;
    _dropdown=_dparttypelist;
    _insert = _iparttypelist;
    [_tlist retain];
    [_dparttypelist retain];
    [_dfunctionlist retain];
    [_dchassislist retain];
    [_ddevicetypelist retain];
    [_tparttypelist retain];
    [_tfunctionlist retain];
    [_tchassislist retain];
    [_lparttypelist retain];
    [_lchassislist retain];
    [_lfunctionlist retain];
    [_ldevicetypelist retain];
    [_llist retain];
    [_dropdown retain];
    [_iparttypelist retain];
    [_ichassislist retain];
    [_ifunctionlist retain];
    [_idevicetypelist retain];
    [_insert retain];

  }

-(void) enableTutorial
{
    [tutorial setEnabled:YES];
}

-(void)showtutorial
{
    [tutorial setEnabled:NO];
    TopAlert *slideDown= [[TopAlert alloc] initWithFrame:[[UIScreen mainScreen]bounds] title:@"Catalog\n"message:@"You can browse the biobricks by type, by function, and by chassis. Under each category, you can find a detailed list of different biobricks. For example, when browse parts by type, there are Promoters, Ribosome Binding Sites (RBS), Protein domains, and others. For each type, there are three sections – list, description, and design. The list section provides a list of all biobricks belongs to this type The description section presents description of each biobrick type. The design section is a platform where you can design a part. "];
    [self.view addSubview:slideDown];
    [slideDown presentView];
    [slideDown release];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enableTutorial)  name: @"okey"  object:nil];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (IBAction)toview1:(id)sender
{
    
    [view2 removeFromSuperview];
    [view3 removeFromSuperview];
    [view4 removeFromSuperview];
    //[self.view bringSubviewToFront:view1];
    
    //_list  =[[NSMutableArray array]init];;
    self._tlist = _tparttypelist;
    self._llist = _lparttypelist;
    self._dropdown=_dparttypelist;
    self._insert = _iparttypelist;
    //Table2 = NULL;
    [Table1 reloadData];
    
}

- (IBAction)toview2:(id)sender
{
    [self.view insertSubview:view2 aboveSubview:self.view];
    self._tlist = _tdevicetypelist;
    self._llist = _ldevicetypelist;
    self._dropdown=_ddevicetypelist;
    self._insert = _idevicetypelist;
    [Table2 reloadData];
    
}
- (IBAction)toview3:(id)sender
{
    [self.view insertSubview:view3 aboveSubview:self.view];
    self._tlist = _tfunctionlist;
    self._llist = _lfunctionlist;
    self._dropdown=_dfunctionlist;
    self._insert = _ifunctionlist;
    [Table3 reloadData];
    
}
- (IBAction)toview4:(id)sender
{
    [self.view insertSubview:view4 aboveSubview:self.view];
    self._tlist = _tchassislist;
    self._llist = _lchassislist;
    self._dropdown=_dchassislist;
    self._insert = _ichassislist;
    [Table4 reloadData];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
   
    return [_tlist count];
  
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  

    return [[_dropdown objectAtIndex:section] count];


}




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CellIdentifier";
    static NSString *DropDownCellIdentifier = @"DropDownCell";
  
    if (indexPath.row==0) {
        DropDownCell *cell = (DropDownCell*) [tableView dequeueReusableCellWithIdentifier:DropDownCellIdentifier];
        
        if (cell == nil){
            
            NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"DropDownCell" owner:nil options:nil];
            
            for(id currentObject in topLevelObjects)
            {
                if([currentObject isKindOfClass:[DropDownCell class]])
                {
                    cell = (DropDownCell *)currentObject;
                    break;
                }
            }
        }
        cell.selectionStyle=[style getCellSelectedStyle];
        [cell.textLabel setFont:[UIFont fontWithName:@"Helvetica" size:16]];

        [[cell textLabel] setText:[self._tlist objectAtIndex:indexPath.section]];
        cell.backgroundColor = [style getCellBackColour];
        cell.textLabel.textColor = [style getCellTextColour];
        cell.textLabel.contentMode = UIControlContentVerticalAlignmentCenter;
        return cell;

    }
            
    else  {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil) {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        }
        
        cell.backgroundColor = [style getCellBackColour];
        cell.textLabel.textColor = [style getCellTextColour];
        cell.textLabel.text=[_list objectAtIndex:indexPath.row-1];
        cell.textLabel.textAlignment = UITextAlignmentRight;
        
        cell.selectionStyle=[style getCellSelectedStyle];
        cell.accessoryType = UITableViewCellStyleValue1;
        cell.textLabel.contentMode=UIControlContentVerticalAlignmentCenter;
        [cell.textLabel setFont:[UIFont fontWithName:@"Helvetica" size:15]];
        
        return cell;
        
    }                   
           
            
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = (UITableViewCell*) [tableView cellForRowAtIndexPath:indexPath];
    cell.selected=NO;
    
    NSMutableArray *indexPathArray = [NSMutableArray arrayWithCapacity:0];

   
    for (int i = 0; i < [[_insert objectAtIndex:indexPath.section] count]-1; i++) {
        NSIndexPath *path = [NSIndexPath indexPathForRow:[indexPath row]+i+1 inSection:[indexPath section]];
        [indexPathArray addObject:path];

    }
    
        [indexPathArray retain]; 
    if (indexPath.row==0) {
        
                DropDownCell *cell = (DropDownCell*) [tableView cellForRowAtIndexPath:indexPath];
                 
                               
                if ([[_dropdown objectAtIndex:indexPath.section] count]>1)
                {
                    [cell setClosed];
                    [_dropdown removeObjectAtIndex:indexPath.section];
                   
                    [_dropdown insertObject:[NSArray arrayWithObjects:@"Promoter", nil] atIndex:indexPath.section];

                    [tableView deleteRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationTop];
                    
                
                }
                else
                {
                    [cell setOpen];
                    [_dropdown removeObjectAtIndex:indexPath.section];
                    [_dropdown insertObject:[self._insert objectAtIndex:indexPath.section] atIndex:indexPath.section];
                    [tableView insertRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationTop];

                }

        
            }
        
            if(indexPath.row==1)
            {
                MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
                [self.navigationController.view addSubview:HUD];
                
                HUD.delegate = self;
                HUD.labelText = @"Loading";
                
                [HUD show:YES];
                dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 0.01 * NSEC_PER_SEC);
                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                    // Do something...
                    UIViewController *targetViewController = [[self._llist objectAtIndex: indexPath.section] objectForKey:kViewControllerKey];
                    [[self navigationController] pushViewController:targetViewController animated:YES];
                    
                    [HUD hide:YES];
                });
                
                
                
            }
            if(indexPath.row==2)
            {
                MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
                [self.navigationController.view addSubview:HUD];
                
                HUD.delegate = self;
                HUD.labelText = @"Loading";
                
                [HUD show:YES];
                dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 0.01 * NSEC_PER_SEC);
                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                    // Do something...
                    UIViewController *targetViewController = [[self._llist objectAtIndex: indexPath.section] objectForKey:pViewControllerKey];
                    [[self navigationController] pushViewController:targetViewController animated:YES];
                    [HUD hide:YES];
                });

                
            }
            if(indexPath.row==3)
            {
                MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
                [self.navigationController.view addSubview:HUD];
                
                HUD.delegate = self;
                HUD.labelText = @"Loading";
                
                [HUD show:YES];
                dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 0.01 * NSEC_PER_SEC);
                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                    // Do something...
                    UIViewController *targetViewController = [[self._llist objectAtIndex: indexPath.section] objectForKey:dViewControllerKey];
                    [[self navigationController] pushViewController:targetViewController animated:YES];
                     [HUD hide:YES];
                });
            }
            
   
    
    
    
   
    
}

////////////////




@end
