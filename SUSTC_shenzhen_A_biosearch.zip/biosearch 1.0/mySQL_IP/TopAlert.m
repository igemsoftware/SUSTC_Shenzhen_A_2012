//
//  TopAlert.m
//  slideDownAlert
//
//  Created by  on 12-7-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TopAlert.h"
@interface TopAlert()
@property  (retain, nonatomic)UILabel *title;///这里retain本来是strong的
@property (retain, nonatomic)UITextView *message;
@property (retain, nonatomic)NSString *sequenceInfo;
@end

@implementation TopAlert
@synthesize sequenceInfo = _sequenceInfo;
@synthesize title;
@synthesize message;
//@synthesize scrollView;

-(id)initWithFrame:(CGRect)frame title:(NSString *)typeName message:(NSString *)typeInfo
{
    self = [self initWithFrame:frame biobrickName:typeName DNASequence:typeInfo];
    return self;
}

-(id)initWithFrame:(CGRect)frame biobrickName:(NSString *)Name DNASequence:(NSString *)sequence
{
 
    if (self) {
        frame.origin.y =  - frame.size.height;
        frame.size.height = frame.size.height;
        // Initialization code
    }  
    self = [super initWithFrame:frame];
    self.alpha = 0.75;
    UIColor *bgColor = [UIColor blackColor];//设置背景颜色！
    self.backgroundColor = bgColor;

    UIButton *buttonRight = [UIButton buttonWithType:UIButtonTypeCustom] ;
    [buttonRight setFrame:CGRectMake(220, 300, 64, 64)];
    [buttonRight setTitle:@"OK" forState:UIControlStateNormal];
    [buttonRight setTitle:@"OK" forState:UIControlStateHighlighted];
    [buttonRight addTarget:self action:@selector(removeView) forControlEvents:UIControlEventTouchUpInside];
    [buttonRight setBackgroundColor:[UIColor clearColor]];
    
    [self addSubview:buttonRight];
   
    //生成title
    title = [[UILabel alloc] initWithFrame:CGRectMake(0, 8, 320, 50)];
    title.text = Name;
    title.textAlignment = UITextAlignmentCenter;
    title.textColor = [UIColor whiteColor];
    title.backgroundColor = [UIColor clearColor];
    title.font = [UIFont boldSystemFontOfSize:17];
    [self addSubview:title];

    message = [[UITextView alloc] initWithFrame:CGRectMake(20, 50, 280, 250)];
    message.delegate = self;
    message.text = sequence;
    
    message.textAlignment = UITextAlignmentLeft;
    message.textColor = [UIColor whiteColor];
    message.backgroundColor = [UIColor clearColor];
    message.font = [UIFont systemFontOfSize:15];
    message.editable = NO;
    [self addSubview:message];

   
    
    
    return self;
}

-(void)removeView
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    [UIView beginAnimations:nil context:context];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.5];
    
    CGRect rect = [self frame];
    rect.origin.y = - rect.size.height;
    [self setFrame:rect];
    
    [UIView commitAnimations];
    [self performSelector:@selector(removeSelf) withObject:self afterDelay:0.5];
    
    NSNotification *notification = [NSNotification notificationWithName:@"okey" object:nil];
    [[NSNotificationCenter defaultCenter] postNotification:notification];
    [[NSNotificationCenter defaultCenter] removeObserver:self name: @"okey" object:nil];
}

-(void)presentView
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    [UIView beginAnimations:nil context:context];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.5];
    
    CGRect rect = [self frame];
    rect.origin.y = 0.0;
    [self setFrame:rect];
    
    [UIView commitAnimations];
   
}

-(void)copyText
{
    [self removeView];
    UIPasteboard *myPasteboard = [UIPasteboard generalPasteboard];
    myPasteboard.string = _sequenceInfo;
}

-(void)removeSelf
{
    [self removeFromSuperview];
}



@end
