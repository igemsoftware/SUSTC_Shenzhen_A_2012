//
//  TopAlert.h
//  slideDownAlert
//
//  Created by  on 12-7-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopAlert : UIView<UITextViewDelegate>

-(id)initWithFrame:(CGRect)frame biobrickName:(NSString *)Name DNASequence:(NSString *)sequence;
-(id)initWithFrame:(CGRect)frame title:(NSString *)typeName message:(NSString *)typeInfo;
-(void)presentView;
-(void)removeView;
@end
