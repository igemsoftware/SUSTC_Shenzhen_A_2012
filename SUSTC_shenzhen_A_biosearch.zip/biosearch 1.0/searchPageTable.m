//
//  searchPageTable.m
//  search
//
//  Created by apple on 12-9-5.
//  Copyright (c) 2012年 apple. All rights reserved.
//

#import "searchPageTable.h"
#import "PartsData.h"
#import "detailpage.h"

@interface searchPageTable ()

@end

@implementation searchPageTable


@synthesize _part_name;
@synthesize _description;
@synthesize _author;
@synthesize _type;
//@synthesize _length1;
//@synthesize _length2;
@synthesize _status;
@synthesize _chassis;
@synthesize _endDate;
@synthesize _startDate;
@synthesize  _searchBarPlayContoller;
@synthesize _sentence;
@synthesize resultController;
-(void)dealloc
{
    [_resultArray release];
    [_temp_resultArray release];
    [_part_name release];
    [_description release];
    [_author release];
    [_type release];
    //[_length1 release];
    //[_length2 release];
    [_status release];
    [_chassis release];
    [_endDate release];
    [_startDate release];
    [style release];
    [resultController release];
    [_searchBarPlayContoller release];
    [_sentence release];
    [super dealloc];


}
-(void) designpredicate
{
    no_result_flag = 0;
    if (_part_name != nil && [_part_name length] != 0)
    {
        if (_AND_flag != 0) {
            [_sentence appendString:@"AND "];
        }
        _part_name = [self decorateString:_part_name];
        [_sentence appendString:@"part_name contains[cd] "];
        [_sentence appendString:_part_name];
        _AND_flag++;
        
    }
    if (_description != nil && [_description length] != 0)
    {
        if (_AND_flag != 0) {
            [_sentence appendString:@"AND "];
            
        }
        _description = [self decorateString:_description];
        [_sentence appendString:@"desc contains[cd] "];
        [_sentence appendString:_description];
        
        
        _AND_flag++;
    }
    if (_author != nil && [_author length] != 0)
    {
        if (_AND_flag != 0) {
            [_sentence appendString:@"AND "];
            
        }
        _author = [self decorateString:_author];
        [_sentence appendString:@"author contains[cd] "];
        [_sentence appendString:_author];
        
        
        _AND_flag++;
    }
    if (_type != nil && [_type length] != 0 && ![_type isEqualToString:@"None"] && ![_type isEqualToString:@"All"])
    {
        if (_AND_flag != 0) {
            [_sentence appendString:@"AND "];
            
        }
        if ([_type isEqualToString: @"Protein domains"]) {
            _type = @"proteindomain";
        }else if([_type isEqualToString:@"Protein coding sequence"]){
            _type = @"coding";
        }else if ([_type isEqualToString:@"Plasmid backbones"]){
            _type = @"plasmidbackbone";
        }else if([_type isEqualToString:@"Primers"]){
            _type = @"primer";
        }else if ([_type isEqualToString:@"Plasmids"]){
            _type = @"plasmid";
        }else if ([_type isEqualToString:@"Translational units"]){
            _type = @"translational_unit";
        }else if ([_type isEqualToString:@"Composite parts"]){
            _type = @"Composite";
        }
        _type = [self decorateString:_type];
        [_sentence appendString:@"( part_type contains[cd] "];
        [_sentence appendString:_type];
        
        [_sentence appendString:@"OR categories contains[cd] "];
        [_sentence appendString:_type];
        [_sentence appendString:@" )"];
        
        _AND_flag++;
    }
    if (_chassis != nil && [_chassis length] != 0 &&![_chassis isEqualToString:@"None"] &&![_chassis isEqualToString:@"All"])
    {
        if (_AND_flag != 0) {
            [_sentence appendString:@"AND "];
            
        }
        _chassis = [self decorateString:_chassis];
        [_sentence appendString:@"categories contains[cd] "];
        [_sentence appendString:_chassis];
        
        _AND_flag++;
    }
    if (_status != nil && [_status length] != 0 && ![_status isEqualToString:@"None"] && ![_status isEqualToString:@"All"])
    {
        if (_AND_flag != 0) {
            [_sentence appendString:@"AND "];
            
        }
        _status = [self decorateString:_status];
        [_sentence appendString:@"status contains[cd] "];
        [_sentence appendString:_status];
        
        _AND_flag++;
    }
  //  NSLog(@"%@",_sentence);
    
    
    if ([_startDate length] != 0 && [_endDate length] != 0 && _startDate != nil && _endDate != nil) {
        if (_AND_flag != 0) {
            [_sentence appendString:@"AND "];
            
        }
        _startDate = [NSString stringWithFormat:@"'%@'", _startDate];
        _endDate = [NSString stringWithFormat:@"'%@'", _endDate];
        [_sentence appendFormat:@"creation_date >= %@ AND creation_date <= %@ ",_startDate,_endDate];
        
        _AND_flag++;
    }
   // NSLog(@"%@",_sentence);
}
-(NSString*) decorateString:(NSString*) input
{
    NSString* _tempPrefix = @"'";
    NSString* _tempPostfix = @"' ";
    input = [_tempPrefix stringByAppendingString:input];
    input = [input stringByAppendingString:_tempPostfix];
    
    [_tempPrefix release];
    [_tempPostfix release];
    
    return input;
}


- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    resultController = [NSFetchedResultsController alloc];
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSearch target:self action:@selector(searchBar:)];
    self.navigationItem.rightBarButtonItem = rightBarButton;
    
    style=[[styleSetting alloc] init];
    UIImageView *_background = [style getTableImage];//[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"羊皮纸.png"]];
    _background.frame = CGRectMake(0, 0, 320, 460);
    
    
    _AND_flag = 0;
    
    _resultArray = [NSMutableArray array];
    _resultArray = nil;
    
    _temp_resultArray  = [NSMutableArray array];
    
    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, 320, 45)];
    [_searchBar setScopeButtonTitles:[NSArray arrayWithObjects:@"df",nil]];
    _searchBar.delegate = self;
    // [_searchBar setTintColor:[UIColor blackColor]];
    // _searchBar.backgroundColor=[UIColor blackColor];
    [_searchBar setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [_searchBar sizeToFit];
    
    _sentence = [[NSMutableString alloc] initWithFormat:@""];
    [self designpredicate];
    [self.tableView setFrame:CGRectMake(0, 0, 320, 370)];
    [self.tableView setTableHeaderView:_searchBar];
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.tableView setContentOffset:CGPointMake(0, 45)];
    
    
    _searchBarPlayContoller = [[UISearchDisplayController alloc] initWithSearchBar:_searchBar contentsController:self];
	[self set_searchBarPlayContoller:_searchBarPlayContoller];
	[_searchBarPlayContoller setDelegate:self];
	[_searchBarPlayContoller setSearchResultsDataSource:self];
    
	//[_searchBar release];
    
    
    //if ([style connectedToNetwork]==NO)
    //{
    //    [self.view addSubview:_background];
    //    [style showNetworkError];
    //}
    [_background release];
    
    

}
-(void)searchBar:(id)sender
{
    self.tableView.frame = CGRectMake(0, 0, 320, 430);
	[_searchBarPlayContoller setActive:YES animated:YES];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    /*if (self.resultController != nil) {
        return;
    }*/
    mySQL_IPAppDelegate *appdelegate = (mySQL_IPAppDelegate*)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext =appdelegate.managedObjectContext;
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"PartsData" inManagedObjectContext:managedObjectContext];
    [request setEntity:entity];
    if ([_sentence length]) {
    NSPredicate *predicate = [NSPredicate predicateWithFormat:_sentence];
    [request setPredicate:predicate];
    }
   // NSLog(@"%@",_sentence);
    NSSortDescriptor *sortDescriptor1 = [[NSSortDescriptor alloc] initWithKey:@"part_name" ascending:YES];
    NSSortDescriptor *sortDescriptor2 = [[NSSortDescriptor alloc] initWithKey:@"in_stock" ascending:NO];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor2,sortDescriptor1,nil];
    [request setSortDescriptors:sortDescriptors];
    [sortDescriptor1 release];
    [sortDescriptor2 release];
    [sortDescriptors release];
    //[NSFetchedResultsController deleteCacheWithName:nil];
    //good!!!!!!!!!!!!!!最后修改处
    [request setPropertiesToFetch:[[NSArray alloc] initWithObjects:@"part_name", nil]];
    NSFetchedResultsController *fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:managedObjectContext sectionNameKeyPath:nil cacheName:_sentence];
    fetchedResultsController.delegate = self;
    NSError *error;
    BOOL success = [fetchedResultsController performFetch:&error];
    if (!success) {
        
    }
    
    self.resultController = fetchedResultsController;
    //NSLog(@"%d",[[self.resultController sections] count]);
    //NSLog(@"%@",[[[self.resultController sections] objectAtIndex:0] name]);
    //NSLog(@"%@",[[[self.resultController sections] objectAtIndex:1] name]);
    //NSLog(@"%@",[[[self.resultController sections] objectAtIndex:2] name]);

    [request release];
    [self.tableView reloadData];
    
    
    
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
//#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return [[self.resultController sections] count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
//#warning Incomplete method implementation.
    // Return the number of rows in the section.

        
    return [[[self.resultController sections] objectAtIndex:section] numberOfObjects];

    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    tableView.backgroundView =  [style getTableImage];
    
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell...
    PartsData *apart = [resultController objectAtIndexPath:indexPath];
    cell.textLabel.text = apart.part_name;
    if ([apart.in_stock isEqualToString:@"1"]) {
        NSString *string =@"In stock";
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@,  %@\n%@" ,apart.status,string,apart.short_desc];
    }
    else{
        NSString *string =@"Not in stock";
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@,  %@\n%@" ,apart.status,string,apart.short_desc];
    }
    
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.detailTextLabel.textColor = [UIColor grayColor];
    
    //[cell.detailTextLabel setText:[NSString stringWithFormat:@"%@,  %@\n%@" ,apart.status,apart.short_desc,apart.desc]];
    [cell.detailTextLabel setNumberOfLines:3];
    [cell.detailTextLabel setTextColor:[UIColor darkGrayColor]];
    cell.textLabel.textColor = [style getCellTextColour];
    
    cell.backgroundColor = [style getCellBackColour];
    
    
    // NSLog(@"part_name = %@", apart.part_name);
    // NSLog(@"%@",apart.desc);
    
    
    return cell;

}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
        return 80;
}
/*-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [[[self.resultController sections] objectAtIndex:section] name];

}
*/
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = (UITableViewCell*) [tableView cellForRowAtIndexPath:indexPath];
    cell.selected=NO;
    
    MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    HUD.delegate = self;
    HUD.labelText = @"Loading";
    
    [HUD show:YES];
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 0.01 * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        // Do something...
        detailpage* _detailPage = [[detailpage alloc] init];
        _detailPage.detail = [resultController objectAtIndexPath:indexPath];

            
        
            
        [self.navigationController pushViewController:_detailPage animated:YES];
        [_detailPage release];
        
        [HUD hide:YES];
    });
}

#pragma mark UISearchDisplayController Delegate Methods
     
- (void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{
	/*
	 Hide the search bar
	 */

    
    self.tableView.frame = CGRectMake(0, 0, 320, 370);
	[self.tableView setContentOffset:CGPointMake(0, 45) animated:YES];
    
    
}
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
        
        
    if (![searchText length]) {
        return;
        
    }
    mySQL_IPAppDelegate *appdelegate = (mySQL_IPAppDelegate*)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext =appdelegate.managedObjectContext;
   // NSLog(@"%@", _sentence);
    //NSLog(@"%@",managedObjectContext);
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"PartsData" inManagedObjectContext:managedObjectContext];
    //NSLog(@"%@",entity);

    [request setEntity:entity];
//NSLog(@"%@", _sentence);
    //NSLog(@"%@", _sentence);
    NSString *string;
    
    if ( ![_sentence length]) {
        string =[NSString stringWithFormat:@"short_desc contains[cd] '%@'",searchText];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:string];
        [request setPredicate:predicate];

    }
    else{
        string =[NSString stringWithFormat:@"%@ AND short_desc contains[cd] '%@'",_sentence,searchText];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:string];
        [request setPredicate:predicate];

        
    }
    //NSLog(@"%@",entity);
    //[request setEntity:entity];
    NSSortDescriptor *sortDescriptor1 = [[NSSortDescriptor alloc] initWithKey:@"part_name" ascending:YES];
    NSSortDescriptor *sortDescriptor2 = [[NSSortDescriptor alloc] initWithKey:@"in_stock" ascending:NO];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor2,sortDescriptor1,nil];
    [request setSortDescriptors:sortDescriptors];
    //最后修改！！！！
    [request setPropertiesToFetch:[[NSArray alloc] initWithObjects:@"part_name", nil]];

    [sortDescriptor1 release];
    [sortDescriptor2 release];
    [sortDescriptors release];
    //[NSFetchedResultsController deleteCacheWithName:nil];
    
    NSFetchedResultsController *fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:managedObjectContext sectionNameKeyPath:nil cacheName:string];
    fetchedResultsController.delegate = self;
    NSError *error;
    BOOL success = [fetchedResultsController performFetch:&error];
    if (!success) {
        
    }
    
    self.resultController = fetchedResultsController;
    [request release];
    [self.tableView reloadData];
    
    
}
-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    mySQL_IPAppDelegate *appdelegate = (mySQL_IPAppDelegate*)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext =appdelegate.managedObjectContext;
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"PartsData" inManagedObjectContext:managedObjectContext];
    [request setEntity:entity];
    if ([_sentence length]) {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:_sentence];
        [request setPredicate:predicate];
    }
    // NSLog(@"%@",_sentence);
    NSSortDescriptor *sortDescriptor1 = [[NSSortDescriptor alloc] initWithKey:@"part_name" ascending:YES];
    NSSortDescriptor *sortDescriptor2 = [[NSSortDescriptor alloc] initWithKey:@"in_stock" ascending:NO];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor2,sortDescriptor1,nil];
    [request setSortDescriptors:sortDescriptors];
    [sortDescriptor1 release];
    [sortDescriptor2 release];
    [sortDescriptors release];
    //[NSFetchedResultsController deleteCacheWithName:nil];
    //最后修改！！！！
    [request setPropertiesToFetch:[[NSArray alloc] initWithObjects:@"part_name", nil]];
    
    NSFetchedResultsController *fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:managedObjectContext sectionNameKeyPath:nil cacheName:_sentence];
    fetchedResultsController.delegate = self;
    NSError *error;
    BOOL success = [fetchedResultsController performFetch:&error];
    if (!success) {
        
    }
    
    self.resultController = fetchedResultsController;
    //NSLog(@"%d",[[self.resultController sections] count]);
    //NSLog(@"%@",[[[self.resultController sections] objectAtIndex:0] name]);
    //NSLog(@"%@",[[[self.resultController sections] objectAtIndex:1] name]);
    //NSLog(@"%@",[[[self.resultController sections] objectAtIndex:2] name]);
    
    [request release];
    [self.tableView reloadData];
    NSLog(@"***************");
    
}
- (void)searchDisplayControllerDidBeginSearch:(UISearchDisplayController *)controller
{
    [self.searchDisplayController.searchResultsTableView setDelegate:self];
}

@end
