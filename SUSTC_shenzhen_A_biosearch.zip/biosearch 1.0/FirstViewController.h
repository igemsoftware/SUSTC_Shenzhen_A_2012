//
//  FirstViewController.h
//  Tab_bar_trial
//
//  Created by Mubing Zhou on 12-7-19.
//  Copyright (c) 2012年 SUSTC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "searchPageTable.h"
#import "mySQL_IPViewController.h"
#import "popUpBox.h"
#import "popUpDatePicker.h"
#import "styleSetting.h"
#import "MBProgressHUD.h"

@interface FirstViewController : UIViewController<UITableViewDelegate, UITableViewDataSource,UITextFieldDelegate,UIActionSheetDelegate, UIAlertViewDelegate,MBProgressHUDDelegate>
{
    
    //由于_textType，_textLength1、2，_lengthArray用不到了，所以最后还要清理一下冗杂的程序
    
    UITableView* _tableView;
    
    UITextField* _textName;     //这个有，必修
    
    UITextField* _textCategory;    //这个就是那个description，必修
    
  //  UITextField* _textLength1, *_textLength2;       //这个有
  //  NSArray* _lengthArray;                          //用来存储上面两个length

    UITextField* _textAuthur;                   //这个有   
    
 //   UITextField* _textType;                     //这个有
    
    popUpBox*  _Type;                       //这个就是那些promoter之类的
    
    popUpBox* _chassis;                      //这个就是biobrcik的受体，什么ecoli啊，yeast啊
    
    popUpBox* _status;                       //这个就是看是否available
    
    popUpDatePicker* _creationDate;          //这个就是搜索creation date么，很明显

    popUpDatePicker* _creationDate2;
    
    NSMutableArray* _allContents;           //所有的选项
    
    NSMutableArray* _currentContents;           //当前已经选择的选项
    
    NSMutableArray* _moreContents;              //剩余的选项
    
    NSMutableArray* _moreOptions;           //用来存储剩余选项的名字
    
    UIBarButtonItem *tutorial;
    
    //UIBarButtonItem *search;
    
    UIBarButtonItem *more;
    
    int _tutorialClickFlag;               //=0代表没有被点

    styleSetting *style;
}

-(UITableViewCell*) processCell : (UITableViewCell*)input atIndex:(int)currentIndex;
//-(int) isValid:(NSString* ) length1  andLength2:(NSString*) length2;
//- (BOOL)isPureInt:(NSString*)string;
-(NSString*) chassis_key_display_map:(NSString*) input;
-(int) isDateValid;
-(NSString*)changeDateIntoString:(NSDate*) date;
-(void) checkTutorial;
-(void) goSearch;
-(void) moreOptions;

@end
