//
//  mySQL_IPViewController.h
//  mySQL_IP
//
//  Created by  apple on 11-7-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

//用于进行ProteinDomain列表的样式修改

#import <UIKit/UIKit.h>
//#import "detailpage.h"
#import <SystemConfiguration/SCNetworkReachability.h>
#import <netinet/in.h> 
#import "styleSetting.h"
#import "MBProgressHUD.h"
#import <CoreData/CoreData.h>
#import "mySQL_IPAppDelegate.h"
@class PartsData;
@class detailpage;


@interface mySQL_IPViewController : UIViewController <UITableViewDelegate,UITableViewDataSource, UISearchDisplayDelegate, UISearchBarDelegate,MBProgressHUDDelegate,NSFetchedResultsControllerDelegate>
{
    UITableView *_DNAList;
    IBOutlet UILabel *_Nametitle;
    NSMutableArray *_DNA;
    NSMutableArray* _temp_DNA;
    NSMutableString *_sentence;
    styleSetting *style;
    
    UISearchBar* _searchBar;                //本页面上二次搜索的
    
    UISearchDisplayController* _searchBarPlayContoller;      //控制上面那货
    NSFetchedResultsController *resultController;
    

        
}


//-(NSMutableArray*) processResult:(NSMutableArray *)resultArray;
//-(NSMutableArray*) lengthDateInOrder:(NSMutableArray*) input;

@property(nonatomic,retain) NSString *Key;
@property(nonatomic,retain) IBOutlet UILabel *_Nametitle;
@property(nonatomic,retain) NSString *name;
@property (nonatomic, retain) UISearchDisplayController	*_searchBarPlayContoller;
@property (nonatomic,retain) NSMutableString *_sentence;
@property (nonatomic, retain) NSFetchedResultsController *resultController;
@end
