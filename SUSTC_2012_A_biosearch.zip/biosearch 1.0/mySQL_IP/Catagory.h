//
//  Catagory.h
//  mySQL_IP
//
//  Created by 熠琦 蒋 on 12-7-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "styleSetting.h"
#import "MBProgressHUD.h"

@interface Catagory : UIViewController<UITableViewDelegate,UITableViewDataSource,MBProgressHUDDelegate>
{
    IBOutlet UIView *view1;
    IBOutlet UIView *view2;
    IBOutlet UIView *view3;
    IBOutlet UIView *view4;
    UITableView *mytable;
    styleSetting *style;
    UIBarButtonItem *tutorial;
        
}
@property(nonatomic,retain)IBOutlet UITableView *Table1;
@property(nonatomic,retain)IBOutlet UITableView *Table2;
@property(nonatomic,retain)IBOutlet UITableView *Table3;
@property(nonatomic,retain)IBOutlet UITableView *Table4;
@property(nonatomic,retain) UIBarButtonItem *tutorial;


@property int index;

- (IBAction)toview1:(id)sender;
- (IBAction)toview2:(id)sender;
- (IBAction)toview3:(id)sender;
- (IBAction)toview4:(id)sender;

@property(nonatomic,retain) NSArray *_list;
@property(nonatomic,retain) NSMutableArray *_tlist;

@property(nonatomic,retain) NSMutableArray *_dropdown;
@property(nonatomic,retain) NSMutableArray *_insert;
@property(nonatomic,retain) NSMutableArray *_dparttypelist;
@property(nonatomic,retain) NSMutableArray *_ddevicetypelist;
@property(nonatomic,retain) NSMutableArray *_dfunctionlist;
@property(nonatomic,retain) NSMutableArray *_dchassislist;

@property(nonatomic,retain) NSMutableArray *_iparttypelist;
@property(nonatomic,retain) NSMutableArray *_idevicetypelist;
@property(nonatomic,retain) NSMutableArray *_ifunctionlist;
@property(nonatomic,retain) NSMutableArray *_ichassislist;

@property(nonatomic,retain) NSMutableArray *_tparttypelist;
@property(nonatomic,retain) NSMutableArray *_tdevicetypelist;
@property(nonatomic,retain) NSMutableArray *_tfunctionlist;
@property(nonatomic,retain) NSMutableArray *_tchassislist;

@property(nonatomic,retain) NSMutableArray *_llist;
@property(nonatomic,retain) NSMutableArray *_lparttypelist;
@property(nonatomic,retain) NSMutableArray *_ldevicetypelist;
@property(nonatomic,retain) NSMutableArray *_lfunctionlist;
@property(nonatomic,retain) NSMutableArray *_lchassislist;

@property NSInteger keynum;

//@property(nonatomic,retain) IBOutlet UITableView *table;
@end
