//
//  experienceWebViewController.h
//  mySQL_IP
//
//  Created by abc on 12-8-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

@interface experienceWebViewController : UIViewController<UIWebViewDelegate,UITabBarControllerDelegate,UINavigationBarDelegate,UINavigationControllerDelegate,MBProgressHUDDelegate>
{
    UIWebView *_web;
    NSString *_URL;
    UIImageView *background;
    UILabel *lable;
    UIToolbar *toolbar;
    MBProgressHUD *HUD;
}

@property (nonatomic, retain) NSString *_URL;

-(void)set_URL:(NSString *)url;


@end
