//
//  TabBarController.h
//  mySQL_IP
//
//  Created by abc on 12-8-13.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "styleSetting.h"
//#import "ASIHTTPRequest.h"
//#import "JSONkit.h"

@class mySQL_IPViewController;
@interface TabBarController : UIViewController<UIApplicationDelegate,UITabBarControllerDelegate, UIAlertViewDelegate>{
    UITabBarController *tab1;
    styleSetting *style;
}

-(void)initwithview;

//@property (nonatomic, retain) mySQL_IPViewController *viewController;
//2012-8-16 周牧兵同学注释掉了上面一行



@end
