//
//  PartsData.m
//  load_xml_to_coredata
//
//  Created by panda on 12-9-3.
//  Copyright (c) 2012年 panda. All rights reserved.
//

#import "PartsData.h"


@implementation PartsData

@dynamic author;
@dynamic categories;
@dynamic creation_date;
@dynamic desc;
@dynamic in_stock;
@dynamic nickname;
@dynamic notes;
@dynamic part_name;
@dynamic part_type;
@dynamic results;
@dynamic sequence;
@dynamic sequence_length;
@dynamic sequence_update;
@dynamic short_desc;
@dynamic source;
@dynamic status;
@dynamic twins;

@end
