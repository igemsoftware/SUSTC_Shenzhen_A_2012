//
//  experienceWebViewController.m
//  mySQL_IP
//
//  Created by abc on 12-8-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "experienceWebViewController.h"
#import "detailpage.h"
#import "styleSetting.h"

@interface experienceWebViewController ()

@end

@implementation experienceWebViewController
@synthesize _URL;

- (void)dealloc
{
    [_URL release];
    [_URL release];
    
    [super dealloc];
}


- (void)viewDidLoad
{

    
    styleSetting *style=[[styleSetting alloc]init];
    background=[style getTableImage];
    background.frame=CGRectMake(0, 0, 320, 480);
    [self.view addSubview:background];

    
    UIBarButtonItem *done=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonItemStyleDone target:self action:@selector(back)];
    
    toolbar=[[UIToolbar alloc] initWithFrame:CGRectMake(0, 20, 320, 40)];
    [toolbar setItems:[NSArray arrayWithObject:done]];
    [toolbar setBarStyle:UIToolbarPositionTop];
    [done release];
    [background release];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    HUD.delegate = self;
    HUD.labelText = @"Loading";
    
    [HUD show:YES];
  
}


- (void)set_URL:(NSString *)url
{

    _URL=[[NSString alloc]initWithString:@""];
    _URL=url;
    _web = [[UIWebView alloc]init];
    [_web loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:_URL]]]; 
    _web.delegate=self;
    _web.frame=CGRectMake(0,0,320,480);
    _web.scalesPageToFit = YES;
    [_web retain];


}

-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    
    [HUD hide:YES];
    [self.view addSubview:_web];
}



- (void)viewDidUnload
{
    [super viewDidUnload];

    [_web release];
    [background release];
    [lable release];
    [toolbar release];
    [_URL release];

}



- (void)loadView {
	
	UIView * first=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 460)];
	first.backgroundColor=[UIColor blackColor];
	self.view = first;
    [first release];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
