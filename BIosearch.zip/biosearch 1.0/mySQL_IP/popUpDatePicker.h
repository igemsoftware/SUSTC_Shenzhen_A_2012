//
//  popUpDatePicker.h
//  mySQL_IP
//
//  Created by abc on 12-8-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface popUpDatePicker : UIView<UIActionSheetDelegate>
{
	UILabel			*selectContentLabel;
	UIButton		*hiddenButton;
    UIDatePicker    *datePicker;
    UIActionSheet   *myActionSheet;
    NSDate          *_minDate;
    NSDate          *_maxDate;
}

@property(nonatomic, retain) UILabel *selectContentLabel;
@property(nonatomic, retain) UIButton *hiddenButton;
@property(nonatomic, retain) UIDatePicker    *datePicker;
@property(nonatomic, retain) UIActionSheet   *myActionSheet;
@property(nonatomic, readonly) NSDate          *_minDate;
@property(nonatomic, readonly) NSDate          *_maxDate;
//@property(nonatomic, readonly) 

@end
