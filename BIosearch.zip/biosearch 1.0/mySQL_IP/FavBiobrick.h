//
//  FavBiobrick.h
//  mySQL_IP
//
//  Created by abc on 12-7-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface FavBiobrick : NSObject
{
	NSString * _id;
    NSString *_desciption;
    NSString *_mymark;
    NSString *_shortdesc;
}


+ (NSArray *) findAll;
+ (int) createWithID:(NSString *) ID description:(NSString *)Description mark:(NSString *)Mymark shortdesc:(NSString *)Shortdesc;
+ (int) delete:(NSString *) ID;
- (id) initWithID:(NSString *) ID description:(NSString *)Description mark:(NSString *)Mymark shortdesc:(NSString *)Shortdesc;
- (NSString *) ID;
- (NSString *) Description;
- (NSString *) Mymark;
- (NSString *) Shortdesc;

@end