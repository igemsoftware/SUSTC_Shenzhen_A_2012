//
//  help.h
//  2ndedits
//
//  Created by abc on 12-7-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "styleSetting.h"

@interface help : UIViewController<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>
{
    UIScrollView *scrollview;
    UITableView *mytable;
    UIWebView *titleview;
 /*   UIButton *help1;
    UIButton *help2;
    UIButton *help3;

    UILabel *help1lb;
    UILabel *help2lb;
    UILabel *help3lb;
    UIButton *syntheticbio;
    UIButton *ourphilosophy;
    UIButton *repository;
    UIButton *parts;*/
    styleSetting *style;
}
@end
