//
//  history.m
//  2ndedits
//
//  Created by abc on 12-7-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "history.h"
#import "FavBiobrick.h"
#import "mySQL_IPAppDelegate.h"
@interface history ()

@end

@implementation history

@synthesize historytable;
@synthesize resultController;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	favBiobricks = [[NSArray alloc] init];
	favBiobricks = [FavBiobrick findAll];
	
	[storeArray removeAllObjects];
	for (id biobrick in favBiobricks) {
		[storeArray addObject:biobrick]; 
	}
    [self sectionstyle:initbrowsetype];
	[historytable reloadData];
	[favBiobricks release];
	
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    //self.navigationController.navigationBarHidden=YES;
    
    style=[[styleSetting alloc]init];
    
    
    UIImageView *_background = [style getTableImage];//[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"羊皮纸.png"]];
    _background.frame = CGRectMake(0, 0, 320, 460);
    [self.view addSubview:_background];
    
    historytable=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 370) style:UITableViewStyleGrouped];
    historytable.delegate=self;
    historytable.dataSource=self;
    historytable.backgroundColor = [UIColor clearColor];
  //  historytable.separatorColor = [style getTableSeperatorColour];
  //  historytable.backgroundColor=[UIColor darkGrayColor];
  //  historytable.backgroundColor=[UIColor colorWithHue:0.2 saturation:0 brightness:0.35 alpha:1];

    //UIBarButtonItem *editButton = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStyleBordered target:self action:@selector(Edit)];
    UIBarButtonItem *editButton = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStyleBordered target:self action:@selector(Edit)];
    UIBarButtonItem *browsetype=[[UIBarButtonItem alloc]initWithTitle:@"browse" style:UIBarButtonItemStyleBordered target:self action:@selector(alertview)];
    [self.navigationItem setLeftBarButtonItems:[[NSArray alloc]initWithObjects:browsetype, nil]];
    [self.navigationItem setRightBarButtonItems:[[NSArray alloc]initWithObjects:editButton, nil]];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
    //self.navigationController.title = @"Book Mark";
    self.navigationItem.title = @"Favorites";

//  *****************************************inserted********************************************
//    [historytable setSeparatorColor:[UIColor whiteColor]];
//    [historytable setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    //UINavigationBar *navbar3=[[UINavigationBar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    //[navbar3 setBarStyle:UIBarStyleBlackOpaque];
    //UINavigationItem *title=[[UINavigationItem alloc]initWithTitle:@"My BookMarks"];
    
    //[navbar3 setBackgroundColor:[UIColor darkGrayColor]];
//  title.titleView.backgroundColor=[UIColor blackColor];
//  title.titleView.frame=CGRectMake(0, 0, 320, 40);
//    [title setTitleView:[[UIImageView alloc]initWithImage:[UIImage imageNamed: @"logo.png"]]];
//    [self.view addSubview:navbar3];
    //[title setRightBarButtonItems:[[NSArray alloc]initWithObjects:editButton, nil] animated:YES];
    //[navbar3 setItems:[[NSArray alloc]initWithObjects:title,nil ]];
    //[self.view addSubview:navbar3];
//  *****************************************inserted********************************************
    
    
    storeArray = [[NSMutableArray alloc] init];
    //detailresults=[[detailpage alloc] init];
//****************************************browse alert************************************************   
   // UIBarButtonItem *browsetype=[[UIBarButtonItem alloc]initWithTitle:@"browse" style:UIBarButtonItemStyleBordered target:self action:@selector(alertview)];
    //[title setLeftBarButtonItems:[[NSArray alloc]initWithObjects:browsetype, nil]];
    
    initbrowsetype=@"mymark";
    sectionarray=[NSMutableArray array];
    NSMutableArray *initarray=[NSMutableArray array];
    [initarray addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"none",@"none", nil]];
    [sectionarray addObject:initarray];
    [sectionarray retain];
    markarray=[NSMutableArray array];
    [markarray addObject:initarray];
    [markarray retain];
    typearray=[NSMutableArray array];
    [typearray addObject:initarray];
    [typearray retain];
    descarray=[NSMutableArray array];
    [descarray addObject:initarray];
    [descarray retain];
    [self.view addSubview:historytable];

}

-(void)alertview
{
    favBiobricks = [[NSArray alloc] init];
	favBiobricks = [FavBiobrick findAll];
	
	[storeArray removeAllObjects];
	for (id biobrick in favBiobricks) {
		[storeArray addObject:biobrick]; 
	}
    alert=[[UIAlertView alloc]initWithTitle:@"browsetype" message:@"way to browse the table" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"by name",@"by catogery",@"by bookmark", nil];
    [alert show];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    sectionarray=[NSMutableArray array];
    NSMutableArray *initarray=[NSMutableArray array];
    [initarray addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"none",@"none", nil]];
    [sectionarray addObject:initarray];

    markarray=[NSMutableArray array];
    [markarray addObject:initarray];
    
    typearray=[NSMutableArray array];
    [typearray addObject:initarray];
    
    descarray=[NSMutableArray array];
    [descarray addObject:initarray];
    
    switch (buttonIndex) {
        case 0:
            break;
        case 1: 
            initbrowsetype=@"ID";
            [self sectionstyle:initbrowsetype];
            break;
        case 2:
            initbrowsetype=@"type";
            [self sectionstyle:initbrowsetype];
            break;
        case 3:
            initbrowsetype=@"mymark";
            [self sectionstyle:initbrowsetype];
            break;
        default:
            break;
    }
}

-(void)sectionstyle:(NSString*)browsekey
{
    sectionarray=[NSMutableArray array];
    NSMutableArray *initarray=[NSMutableArray array];
    [initarray addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"none",@"none", nil]];
    [sectionarray addObject:initarray];
    
    
    markarray=[NSMutableArray array];
    [markarray addObject:initarray];
    
    typearray=[NSMutableArray array];
    [typearray addObject:initarray];
 
    descarray=[NSMutableArray array];
    [descarray addObject:initarray];
    for (int i = 0; i<[storeArray count]; i++) {
        
        NSString *arrangekey=[[NSString alloc]initWithString:@""];
        
        if ([browsekey compare:@"ID"]==0) {
            arrangekey=[[NSString alloc]initWithString:[[storeArray objectAtIndex:i] ID]];
        }
        else if ([browsekey compare:@"type"]==0) {
                arrangekey=[[NSString alloc]initWithString:[[storeArray objectAtIndex:i] Description]];
                   }
        else if([browsekey compare:@"mymark"]==0) {
            arrangekey=[[NSString alloc]initWithString:[[storeArray objectAtIndex:i] Mymark]];
        }
     
       
        int insertindex=[self insertkey:arrangekey];
        
        if (insertindex>-1) {
            [[sectionarray objectAtIndex:insertindex]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[[storeArray objectAtIndex:i] ID],arrangekey ,nil]];
            [[typearray objectAtIndex:insertindex]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[[storeArray objectAtIndex:i] Description],arrangekey ,nil]];
             [[markarray objectAtIndex:insertindex]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[[storeArray objectAtIndex:i] Mymark],arrangekey ,nil]];
             [[descarray objectAtIndex:insertindex]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[[storeArray objectAtIndex:i] Shortdesc],arrangekey ,nil]];
        }
        else {
            NSMutableArray *insertarray=[NSMutableArray array];
            [insertarray addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[[storeArray objectAtIndex:i]ID], arrangekey,nil]];
            [sectionarray addObject:insertarray];
            NSMutableArray *inserttype=[NSMutableArray array];
            [inserttype addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[[storeArray objectAtIndex:i]Description], arrangekey,nil]];
            [typearray addObject:inserttype];
            NSMutableArray *insertmark=[NSMutableArray array];
            [insertmark addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[[storeArray objectAtIndex:i]Mymark], arrangekey,nil]];
            [markarray addObject:insertmark];
            NSMutableArray *insertdesc=[NSMutableArray array];
            [insertdesc addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[[storeArray objectAtIndex:i]Shortdesc], arrangekey,nil]];
            [descarray addObject:insertdesc];

        }
    }
    
    [typearray retain];
    [markarray retain];
    [sectionarray retain];
    [descarray retain];
    

    [historytable reloadData];
}
/*
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [[[[sectionarray objectAtIndex:section+1] objectAtIndex:0]allKeys] objectAtIndex:0];
}
*/

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 30;
}

/*-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *sectiontitle=[[UIView alloc] init];
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 300, 20)];
    _titleLabel.text = [[[[sectionarray objectAtIndex:section+1] objectAtIndex:0]allKeys] objectAtIndex:0];
    _titleLabel.textColor = [style getCellTextColour];
    _titleLabel.backgroundColor = [UIColor clearColor];
    [sectiontitle addSubview:_titleLabel];
    return sectiontitle;
}*/

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
 return [[[[sectionarray objectAtIndex:section+1] objectAtIndex:0]allKeys] objectAtIndex:0];   
}

-(int)insertkey:(NSString *)arrangekey
{
    int j=0;
    int index=-1;
    NSString *comparekey=[[NSString alloc]initWithString:@""];
    for ( j = 0 ; j < [sectionarray count]; j++ ) {
       
        NSString *key=[[[[sectionarray objectAtIndex:j] objectAtIndex:0] allKeys] objectAtIndex:0];
        comparekey=[[NSString alloc]initWithString:key];
        if ([comparekey compare:arrangekey]==0) {
            index=j;
            break;
        }
    }
    return index;
    
    
}
//****************************************browse alert************************************************   



- (void) Edit{
	
	[historytable setEditing:!historytable.editing animated:YES];
	if(historytable.editing)
		self.navigationItem.rightBarButtonItem.title = @"Done";
	else
		self.navigationItem.rightBarButtonItem.title = @"Edit";
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    int result=[sectionarray count]-1;
    return result;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[sectionarray objectAtIndex:section+1] count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // Configure the cell...
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
    }//当cell为空的时候，创建一个cell

    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle=[style getCellSelectedStyle];
   // FavBiobrick *favBiobrick = [storeArray objectAtIndex:indexPath.row];

   // [cell.textLabel setFont:[UIFont fontWithName:@"Cochin" size:17]];
    cell.textLabel.backgroundColor = [UIColor clearColor];
    cell.textLabel.textColor = [style getCellTextColour];
    cell.backgroundColor = [style getCellBackColour];

    cell.textLabel.text=[[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] objectForKey:[[[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] allKeys]objectAtIndex:0]];

    tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    
    NSString *detailmark=[[NSString alloc]initWithString:@"Bookmark:  "];
    detailmark=[detailmark stringByAppendingString:[[[markarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] objectForKey:[[[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] allKeys]objectAtIndex:0]]];
    detailmark=[detailmark stringByAppendingString:@"\nCatetory:  "];
    detailmark=[detailmark stringByAppendingString:[[[typearray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] objectForKey:[[[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] allKeys]objectAtIndex:0]]];
    detailmark=[detailmark stringByAppendingString:@"\nShort descrtiption:  "];
    detailmark=[detailmark stringByAppendingString:[[[descarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] objectForKey:[[[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] allKeys]objectAtIndex:0]]];
    cell.detailTextLabel.text=detailmark;
    [cell.detailTextLabel setNumberOfLines:5];

    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	
	HUD.delegate = self;
	HUD.labelText = @"Loading";
    
    [HUD show:YES];
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 0.01 * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        // Do something...
        mySQL_IPAppDelegate *appdelegate = (mySQL_IPAppDelegate*)[[UIApplication sharedApplication] delegate];
        NSManagedObjectContext *managedObjectContext =appdelegate.managedObjectContext;
        //NSLog(@"%@", _sentence);
        //NSLog(@"%@",managedObjectContext);
        NSFetchRequest *request = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"PartsData" inManagedObjectContext:managedObjectContext];
        //NSLog(@"%@",entity);
        
        [request setEntity:entity];
        //NSLog(@"%@", _sentence);
        //NSLog(@"%@", _sentence);
        
        /*if ( ![_sentence length]) {
         NSString *string =[NSString stringWithFormat:@"part_name contains[cd] '%@'",searchText];
         NSPredicate *predicate = [NSPredicate predicateWithFormat:string];
         [request setPredicate:predicate];
         
         }
         else{
         NSString *string =[NSString stringWithFormat:@"%@ AND part_name contains[cd] '%@'",_sentence,searchText];
         NSPredicate *predicate = [NSPredicate predicateWithFormat:string];
         [request setPredicate:predicate];
         
         
         }
         */
        //NSLog(@"%@",entity);
        //[request setEntity:entity];
        NSSortDescriptor *sortDescriptor1 = [[NSSortDescriptor alloc] initWithKey:@"part_name" ascending:YES];
        //NSSortDescriptor *sortDescriptor2 = [[NSSortDescriptor alloc] initWithKey:@"in_stock" ascending:YES];
        NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor1,nil];
        [request setSortDescriptors:sortDescriptors];
        //[sortDescriptor1 release];
        //[sortDescriptor2 release];
        //[sortDescriptors release];
        NSString *mystring = [[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] objectForKey:[[[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] allKeys]objectAtIndex:0]];
        NSString *string =[NSString stringWithFormat:@"part_name == '%@'",[[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] objectForKey:[[[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] allKeys]objectAtIndex:0]]];
        NSLog(@"%@",string);
        NSPredicate *predicate = [NSPredicate predicateWithFormat:string];
        //good!!!!!!!!!!!!!!最后修改处
        [request setPropertiesToFetch:[[NSArray alloc] initWithObjects:@"part_name", nil]];
        [request setPredicate:predicate];
        
        [NSFetchedResultsController deleteCacheWithName:nil];
        
        NSFetchedResultsController *fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:managedObjectContext sectionNameKeyPath:nil cacheName:mystring];
        fetchedResultsController.delegate = self;
        NSError *error;
        BOOL success = [fetchedResultsController performFetch:&error];
        if (!success) {
            
        }
        
        self.resultController = fetchedResultsController;
        NSLog(@"%@",indexPath);
        NSIndexPath *path=[NSIndexPath indexPathForRow:0 inSection:0];
        
        detailpage *detailresults = [[detailpage alloc] init];
        detailresults.detail =[resultController objectAtIndexPath:path];
        [self.navigationController pushViewController:detailresults animated:YES];
        [detailresults release];
        [HUD hide:YES];
    });
    
    // [self pushtodetail:indexPath];
    
}




- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{	
    [FavBiobrick delete:[[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] objectForKey:[[[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row] allKeys]objectAtIndex:0]]];
    if ([[sectionarray objectAtIndex:indexPath.section+1]count]==1) {
        [sectionarray removeObject:[sectionarray objectAtIndex:indexPath.section+1]];
        [tableView deleteSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationRight];

    }
    else {
        [[sectionarray objectAtIndex:indexPath.section+1] removeObject:[[sectionarray objectAtIndex:indexPath.section+1] objectAtIndex:indexPath.row]];
       	[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationRight];
    }


    

}



- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
	return YES;
}

/*- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath 
{
    NSUInteger fromSection=[sourceIndexPath section];
    NSUInteger toSection=[destinationIndexPath section];
    NSUInteger fromRow = [sourceIndexPath row]; 
    NSUInteger toRow = [destinationIndexPath row]; 
    if (fromSection==toSection) {
        id object = [[sectionarray objectAtIndex:fromSection+1] objectAtIndex:fromRow]; 
        [[sectionarray objectAtIndex:fromSection+1] removeObject:[[sectionarray objectAtIndex:fromSection+1] objectAtIndex:fromRow]];
        [[sectionarray objectAtIndex:toSection]insertObject:object atIndex:toRow];
    }
   
}*/


- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return UITableViewCellEditingStyleDelete;
}

- (void)loadView {
	
	UIView * first=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
	first.backgroundColor=[UIColor blackColor];
	self.view=first;
}


- (void)viewDidUnload
{
    
    [super viewDidUnload];
    [style release];
    [historytable release];
    [storeArray release];
	[detailBiobrick release];
    //[detailresults release];
	[favBiobricks release];
    //****************************************browse alert************************************************   
    
    [sectionarray release];
    [markarray release];
    [typearray release];
    [descarray release];
    [alert release];
    [initbrowsetype release];
    [style release];
    [_titleLabel release];
    [resultController release];

    // Release any retained subviews of the main view.
}

-(void)viewDidDisappear:(BOOL)animated
{
    
    sectionarray=[NSMutableArray array];
    NSMutableArray *initarray=[NSMutableArray array];
    [initarray addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"none",@"none", nil]];
    [sectionarray addObject:initarray];
    [sectionarray retain];
    [initbrowsetype retain];

}



-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 140;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
