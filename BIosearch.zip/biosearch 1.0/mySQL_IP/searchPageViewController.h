//
//  searchPageViewController.h
//  mySQL_IP
//
//  Created by Mubing Zhou on 12-7-24.
//  Copyright (c) 2012年 SUSTC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MysqlManager.h"
#import "detailpage.h"
#import "popUpBox.h"
#import "styleSetting.h"
#import "MBProgressHUD.h"


@interface searchPageViewController : UIViewController<UISearchBarDelegate, UITableViewDelegate,UITableViewDataSource, UINavigationControllerDelegate, UISearchBarDelegate , UISearchDisplayDelegate,MBProgressHUDDelegate>
{
    //_type，_length1，_length2都不会用到了，记着清除冗杂的程序哦~， 
    
    UITableView* _tableView;
    
    NSMutableArray* _resultArray;
    
    NSMutableArray* _temp_resultArray;
    
    NSString* _part_name;        //搜索的数据库中的那一列名为part_name
    
    NSString* _description;     //这个和firstviewcontroller的category相对应
    
    NSString* _author;           //搜索的数据库中的那一列名为author
    
    NSString* _type;            //搜索的数据库中的那一列名为  part_type  ps:这一个先不管
    
  //  NSString* _length1, *_length2;
    
    NSString* _status;          //搜索的数据库中的那一列名为status
    
    NSString* _chassis;          //搜索的数据库中的那一列名为categories
    
    NSString* _startDate;        //顾名思义
    
    NSString* _endDate;        //顾名思义
    
    int _AND_flag;
    
    styleSetting *style;
    
    UISearchBar* _searchBar;                //本页面上二次搜索的
    
    UISearchDisplayController* _searchBarPlayContoller;      //控制上面那货
    
    int no_result_flag;     //当搜索结果为空时，此值设为1
    
    
    
}

-(void) search;
-(NSString*) decorateString:(NSString*) input;
-(NSMutableArray*) processResult:(NSMutableArray*) resultArray;
-(NSMutableArray*) lengthDateInOrder:(NSMutableArray*) input;
-(void)searchInSearchBar:(NSString *)key;

@property (nonatomic, retain) NSString* _part_name;
@property (nonatomic, retain) NSString* _description;
@property (nonatomic, retain) NSString* _author;
@property (nonatomic, retain) NSString* _type;
//@property (nonatomic, retain) NSString* _length1;
//@property (nonatomic, retain) NSString* _length2;
@property (nonatomic, retain) NSString* _status;
@property (nonatomic, retain) NSString* _chassis;
@property (nonatomic, retain) NSString* _startDate;
@property (nonatomic, retain) NSString* _endDate;
@property (nonatomic, retain) UISearchDisplayController	*_searchBarPlayContoller;


@end
