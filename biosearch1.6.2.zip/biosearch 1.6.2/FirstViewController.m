//
//  FirstViewController.m
//  Tab_bar_trial
//
//  Created by Mubing Zhou on 12-7-19.
//  Copyright (c) 2012年 SUSTC. All rights reserved.
//

#import "FirstViewController.h"
#import "searchPageTable.h"
#import "TopAlert.h"

#define _height_of_row_in_table  44.0
//#define _table_view_height  370
#define _text_field_up_distance_to_cell_top  10
//370

@interface FirstViewController ()
@property CGFloat table_view_height;
@end

@implementation FirstViewController
@synthesize table_view_height = _table_view_height;

-(void)dealloc
{
    [_allContents release];
    [_currentContents release];
    [_moreOptions release];
    [_moreContents release];
    
    [super dealloc];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _table_view_height = self.view.frame.size.height;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //self.view.backgroundColor = [UIColor whiteColor];
	// Do any additional setup after loading the view.
    //self.navigationController.navigationBarHidden = NO;
    //self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationItem.title = @"Search";
    
    style=[[styleSetting alloc] init];
    
    tutorial = [[UIBarButtonItem alloc] initWithTitle:@"Tutorial" style:UIBarButtonItemStyleBordered target:self action:@selector(showtutorial)];
    [tutorial setEnabled:YES];
    [self.navigationItem setLeftBarButtonItems:[NSArray arrayWithObjects:tutorial, nil]];
    
    //search=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSearch target:self action:@selector(goSearch)];
    more = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCompose target:self action:@selector(moreOptions)];
    [self.navigationItem setRightBarButtonItems:[NSArray arrayWithObjects:more,nil]];
    
    
    
    UIImageView *_background = [style getTableImage];
    _background.frame = self.view.frame;
    _background.frame = CGRectMake(0, 0, 320, 460);
    [self.view addSubview:_background];
    //[_background release];
    
    //_tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, _table_view_height) style:UITableViewStyleGrouped];
    CGRect tableFrame = self.view.frame;
    tableFrame.size.height = tableFrame.size.height-84;
    tableFrame.origin.y = tableFrame.origin.y-20;
    _tableView = [[UITableView alloc] initWithFrame:tableFrame style:UITableViewStyleGrouped];
    _tableView.backgroundView = nil;
    _tableView.backgroundColor = [UIColor clearColor];
    //记号，table
    _tableView.delegate =self;
    _tableView.dataSource = self;
    //_tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    
    _textName = [[UITextField alloc] initWithFrame:CGRectMake(143, _text_field_up_distance_to_cell_top, 180, _height_of_row_in_table)];
    _textName.backgroundColor = [UIColor clearColor];
    _textName.placeholder = @"e.g.  BBa_I14050";
    _textName.textAlignment = UITextAlignmentLeft;
    _textName.keyboardType = UIKeyboardTypeAlphabet;
    _textName.returnKeyType = UIReturnKeyDone;
    _textName.delegate = self;
    _textName.tag = 1;
    
    _textCategory = [[UITextField alloc] initWithFrame:CGRectMake(143, _text_field_up_distance_to_cell_top, 180, _height_of_row_in_table)];
    _textCategory.backgroundColor = [UIColor clearColor];
    _textCategory.delegate = self;
    _textCategory.placeholder = @"e.g.  GFP protein";   
    _textCategory.tag = 2;
    
    _textAuthur = [[UITextField alloc] initWithFrame:CGRectMake(143, _text_field_up_distance_to_cell_top, 180, _height_of_row_in_table)];
    _textAuthur.placeholder = @"e.g Molly";
    _textAuthur.delegate = self;
    _textAuthur.keyboardType = UIKeyboardTypeAlphabet;
    _textAuthur.returnKeyType = UIReturnKeyDone;
    _textAuthur.tag = 5;
    
    _Type = [[popUpBox alloc] initWithFrame:CGRectMake(143,0, 150, _height_of_row_in_table)];
    NSArray* _type_data = [[NSArray alloc] initWithObjects:@"All",@"Promoter", @"Terminator", @"RBS",@"Protein domains",@"Protein coding sequence",@"Plasmid backbones",@"Plasmids",@"Primers",@"Translational units",@"DNA",@"Composite parts",@"Generator",@"Reporter", @"Inverter",@"Measurement", nil];
    _Type.popUpBoxDatasource = _type_data;
    _Type.selectContentLabel.text = [_type_data objectAtIndex:0];
    _Type.selectContentLabel.textColor = [UIColor grayColor];
    
    _chassis = [[popUpBox alloc] initWithFrame:CGRectMake(143, 0, 150, _height_of_row_in_table)];
    NSArray* _chassis_data = [[NSArray alloc] initWithObjects:@"All",@"E.coli",@"Yeast",@"Bacteriophage T7",@"Bacillus subtilis",nil ];//,@"MammoBlocks",nil];
    _chassis.popUpBoxDatasource = _chassis_data;
    _chassis.selectContentLabel.text = [_chassis_data objectAtIndex:0];
    _chassis.selectContentLabel.textColor = [UIColor grayColor];
    
    _status = [[popUpBox alloc] initWithFrame:CGRectMake(143,0, 150, _height_of_row_in_table)];
    NSArray* _status_data = [[NSArray alloc] initWithObjects:@"All",@"Available",@"Planning",@"Building",@"Cancelled",@"Deleted",@"Length OK", @"Missing",@"Sent",@"Unavailable", nil];
    _status.popUpBoxDatasource = _status_data;
    _status.selectContentLabel.text = [_status_data objectAtIndex:0];
    _status.selectContentLabel.textColor = [UIColor grayColor];
    
    _creationDate = [[popUpDatePicker alloc] initWithFrame:CGRectMake(143,0, 150, _height_of_row_in_table)];
    _creationDate.selectContentLabel.text = @"Pick a start date";
    _creationDate.selectContentLabel.textColor = [UIColor grayColor];
    _creationDate2 = [[popUpDatePicker alloc] initWithFrame:CGRectMake(143,0, 150, _height_of_row_in_table)];
    _creationDate2.selectContentLabel.text = @"Pick an end date";
    _creationDate2.selectContentLabel.textColor = [UIColor grayColor];
    [_creationDate.datePicker setDate:_creationDate._minDate];
    [_creationDate2.datePicker setDate:_creationDate2._maxDate];
    
    
    _moreOptions = [[NSMutableArray alloc] initWithObjects:@"Author", @"Status",@"Creation date",nil] ;//]] @"Creation date", nil];
    
    _allContents = [[NSMutableArray alloc] initWithObjects:_textName, _textCategory,_chassis,_Type,_textAuthur, _status,_creationDate, nil];
    
    _currentContents = [[NSMutableArray alloc] initWithObjects:_textName, _textCategory,_chassis, _Type, nil];
    
    _moreContents = [[NSMutableArray alloc] initWithObjects: _textAuthur,_status,_creationDate, nil];
    
    
    [self.view addSubview:_tableView];
    
    // NSUserDefaults *firstlaunch=[[NSUserDefaults alloc]init];
    // [firstlaunch setBool:YES forKey:@"firstlaunch"];
    [_background release];
   
    [_type_data release];
    [_chassis_data release];
    [_status_data release];
}


-(void)showtutorial
{
   // [search setEnabled:NO];
    [more setEnabled:NO];
    [tutorial setEnabled:NO];
    TopAlert *slideDown= [[TopAlert alloc] initWithFrame:[[UIScreen mainScreen]bounds] title:@"Search page Tutorial\n" message:@"Click the text field after Name, you will enter the name of your wanted biobrick or part of its name. Click the button after 'Chassis', you can choose the organism in which you want your biobrick works. Advanced options allow you to add more detailed searching condition.\n\nYou can search biobricks by name or chassis: simply enter the name of the parts or devices you are looking for in the text field after Name, or click the button after Chassis to choose the organism in which your biobricks works. Advanced options allow you to enter more specific search criteria."];
    UIImageView *morebtn=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"more btn.png"]];
    morebtn.frame=CGRectMake(30, 220, 23, 20);
    UIImageView *searchbtn=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"search btn.png"]];
    searchbtn.frame=CGRectMake(29, 240, 25, 20);
    [self.view addSubview:slideDown];
    [slideDown presentView];
    [slideDown release];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enableTutorial)  name: @"okey"  object:nil];
}

-(void) enableTutorial
{
   // [search setEnabled:YES];
    if ([_moreOptions count]>=1) {
        [more setEnabled:YES];
    }
    [tutorial setEnabled:YES];
}

-(void)checkTutorial
{
    if (_tutorialClickFlag == 0)
    {
        [tutorial setEnabled:YES];
        _tutorialClickFlag = 1;
    }
    if (_tutorialClickFlag == 1)
    {
        [tutorial setEnabled:NO];
        _tutorialClickFlag = 0;
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [_tableView release];
    [_textName release];
    [_textCategory release];
    [_textAuthur release];
    [_status release];
    [_Type release];
    [_chassis release];
    [_creationDate release];
    [_creationDate2 release];
    [style release];
    [tutorial release];
  //  [search release];
    [more release];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return  YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{               //to limit the number of words that user inputs
    switch (textField.tag) {
        case 1:                 //textname
            if (range.location >= 15)
                return NO; // return NO to not change text
            return YES;
            break;
            
        case 2:                 //description
            if (range.location >= 25)
                return NO; // return NO to not change text
            return YES;
            break;
            
        case 5:                 //author
            if (range.location >= 25)
                return NO; // return NO to not change text
            return YES;
            break;
            
        default:
            return YES;
            break;
    }
    
    
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    textField.textColor = [UIColor blackColor];
    if (textField.tag == 2)   //description
    {
        [UIView beginAnimations:@"Animation" context:nil];
        [UIView setAnimationDuration:0.3];
        //CGRect tableFrame = self.view.frame;
        //tableFrame.origin.y = tableFrame.origin.y - 40;
        _tableView.frame = CGRectMake(0, -40, 320, _table_view_height);//记号
        [UIView commitAnimations];
    }
    
    if (textField.tag == 5)        //_textAuthur
    {
        float diff = 0 - _tableView.contentOffset.y + textField.superview.frame.origin.y;
        if ( diff > 180 && diff < 230) {
            [UIView beginAnimations:@"Animation" context:nil];
            [UIView setAnimationDuration:0.3]; 
            _tableView.frame = CGRectMake(0, -100, 320, _table_view_height);
            [UIView commitAnimations];
        }
        else if (diff > 230) {
            [UIView beginAnimations:@"Animation" context:nil];
            [UIView setAnimationDuration:0.3]; 
            _tableView.frame = CGRectMake(0, -170, 320, _table_view_height);
            [UIView commitAnimations];
        }
        
    }
    
    return YES;
}




-(BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    [UIView beginAnimations:@"Animation" context:nil];
    [UIView setAnimationDuration:0.3]; 
    _tableView.frame = CGRectMake(0, 0, 320, _table_view_height);
    [UIView commitAnimations];
    return YES;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //    NSLog(@"sections of table = %d", [_currentContents count] + 2);
    return ([_currentContents count] + 1);          //多加一个search的cell
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //    NSLog(@"number of rows in section = 1");
    if (section < [_currentContents count]) {
        if ([_currentContents objectAtIndex:section] == _creationDate) {
            return 3;
        }
    }
    
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return _height_of_row_in_table;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // Configure the cell...
    if (cell == nil) {
        //cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        
    }
    cell.textLabel.textAlignment = UITextAlignmentLeft;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [style getCellBackColour];
    
    cell.textLabel.textColor = [style getCellTextColour];
    cell.textLabel.font = [UIFont systemFontOfSize:18.0f];
    cell.textLabel.text = @"";
    //   cell.backgroundView = NULL;
    UIView* _subView;
    for (int j = 0; j < [[cell subviews] count]; j++) 
    {   
        _subView = [[cell subviews] objectAtIndex:j];
        
        for (int i = 0; i < [_currentContents count]; i++) 
        {
            if (_subView == [_currentContents objectAtIndex:i]) 
            {
                [[[cell subviews] objectAtIndex:j] removeFromSuperview];
            }
            if (_subView == _creationDate2) {
                [_subView removeFromSuperview];
            }
        }
        
    }
    
    if(indexPath.section != _tableView.numberOfSections -1)
    {
        if (indexPath.row == 0) {
            if (indexPath.section < [_currentContents count]) {
                switch (indexPath.section) {
                    case 0:
                        //   NSLog(@"I am here! 000000000000000000");
                        cell.textLabel.text = @"Name";
                        //   NSLog(@"_textName loaded!!!!!");
                        [cell addSubview:_textName];
                        break;
                    case 1:
                        //   NSLog(@"I am here! 111111111111111111");
                        cell.textLabel.text = @"Keywords";
                        [cell addSubview:_textCategory];
                        break;
                    case 2:
                        //   NSLog(@"I am here! 222222222222222222");
                        cell.textLabel.text = @"Chassis";
                        [cell addSubview:_chassis];
                        break;
                    case 3:
                        //   NSLog(@"I am here! 3333333333333333333");
                        cell.textLabel.text = @"Type";
                        [cell addSubview:_Type];
                        break;
                    case 4:
                        //   NSLog(@"I am here! 4444444444444444444");
                        cell.textLabel.text =@"";
                        cell = [self processCell:cell atIndex:4];
                        break;
                    case 5:
                        
                        cell.textLabel.text =@"";
                        cell = [self processCell:cell atIndex:5];
                        break;
                    case 6:
                        cell.textLabel.text =@"";
                        cell = [self processCell:cell atIndex:6];
                        break;
                        
                    default:
                        break;
                }
            } 
            
        }
        else if (indexPath.row == 1)
        {
            [cell addSubview:_creationDate];
            cell.textLabel.text = @"Start date";
            cell.textLabel.font = [UIFont systemFontOfSize:13.0f];
            
            return cell;
        }
        else if (indexPath.row == 2)
        {
            cell.textLabel.text = @"End date";
            cell.textLabel.font = [UIFont systemFontOfSize:13.0f];
            [cell addSubview:_creationDate2];
            return  cell;
        }
    }
    else {
        cell.textLabel.text = @"                       Search";
        //UIImageView *searchButton = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"searchBottun.png"]];
        //cell.backgroundView = searchButton;
        cell.backgroundColor = [UIColor lightGrayColor];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
    
    //  [_subView release];
    
    return cell; 
    
    
}

-(UITableViewCell*) processCell : (UITableViewCell*)input atIndex:(int)currentIndex
{
    if ([_currentContents objectAtIndex:currentIndex] == _textAuthur) {
        input.textLabel.text = @"Author";
        [input addSubview:_textAuthur];
    }
    if ([_currentContents objectAtIndex:currentIndex] == _status) {
        input.textLabel.text = @"Status";
        [input addSubview:_status];
    }
    if ([_currentContents objectAtIndex:currentIndex] == _creationDate) {
        
        input.textLabel.text = @"Creation date";
    }
    return input;
}


-(void)goSearch
{
    if ([self isDateValid] == 1) {
        
        MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
        [self.navigationController.view addSubview:HUD];
        
        HUD.delegate = self;
        HUD.labelText = @"Loading";
        
        [HUD show:YES];
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 0.01 * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            // Do something...
            searchPageTable* _searchPage = [[searchPageTable alloc] init];
            _searchPage._part_name = _textName.text;
            _searchPage._description = _textCategory.text;
            _searchPage._author = _textAuthur.text;
            // _searchPage._length2 = _textLength2.text;
            // _searchPage._length1 = _textLength1.text;
            _searchPage._type = _Type.selectContentLabel.text;
            _searchPage._chassis = [self chassis_key_display_map:  _chassis.selectContentLabel.text];
            _searchPage._status = _status.selectContentLabel.text;
            _searchPage._startDate = [self changeDateIntoString:_creationDate.datePicker.date];
            _searchPage._endDate = [self changeDateIntoString:_creationDate2.datePicker.date];            
            
            [self.navigationController pushViewController:_searchPage animated:YES];
            
            [HUD hide:YES];
        });
        
    }
    
    else
    {
        UIAlertView* _alertView1 = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Start date should be earlier than end date!" delegate:self cancelButtonTitle:@"All right" otherButtonTitles:nil, nil];
        
        [_alertView1 show];
    }    
}

-(void)moreOptions
{
    if ( [_moreOptions count] > 0 ) {
        UIActionSheet* _actionSheet = [[UIActionSheet alloc] initWithTitle:@"Please select a keyword" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:nil, nil];
        for (int i = 0; i < [_moreOptions count]; i++) 
        {
            [_actionSheet addButtonWithTitle:[_moreOptions objectAtIndex:i]];
        }
        [_actionSheet showInView:self.view.window];
        
    }
    
    else {
        
    }
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == (_tableView.numberOfSections - 1)) {
        [self goSearch];
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
}


-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if ([_moreOptions count] > 0 && buttonIndex != 0) 
    {
        [_currentContents addObject:[_moreContents objectAtIndex:buttonIndex - 1]];
        [_moreOptions removeObjectAtIndex:buttonIndex - 1];
        [_moreContents removeObjectAtIndex:buttonIndex - 1];        
        [_tableView reloadData];
    }
   // NSLog(@"numbersOfChoices=%d",[_moreOptions count]);
    if ([_moreOptions count]==0) {
        [more setEnabled:NO];
    }
}


-(NSString*) chassis_key_display_map:(NSString*) input
{
    if ([input isEqualToString:@"Bacteriophage T7"]) {
        return @"Bacteriophage";
    }
    else if ([input isEqualToString:@"Bacillus subtilis"]) {
        return @"Bacillus";
    }
    else if ([input isEqualToString:@"E.coli"]) {
        return @"Ecoli";
    }
    else if ([input isEqualToString:@"MammoBlocks"]) {
        return @"";//需要修改。
    }
    else {
        return input;
    }
}

-(int)isDateValid
{
    NSComparisonResult result;
    result = [_creationDate.datePicker.date compare:_creationDate2.datePicker.date];
    if (result == NSOrderedAscending  || result == NSOrderedSame)  
    {
        return 1;
    }
    else if (result == NSOrderedAscending) 
    {
        return 0;
    }
    else 
    {
        return 0;
    }
    
}

-(NSString*)changeDateIntoString:(NSDate*) date
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat: @"yyyy-MM-dd"];
    
    return  [dateFormatter stringFromDate:date];
}

@end
