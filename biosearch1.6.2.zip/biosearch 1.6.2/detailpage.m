//
//  detailpage.m
//  mySQL_IP
//
//  Created by abc on 12-8-13.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "detailpage.h"
#import "searchPageTable.h"
//#import "MysqlManager.h"
#import "PartsData.h"
@interface detailpage ()

@end

@implementation detailpage

@synthesize _part_name;
@synthesize detail;

- (void)dealloc
{
    [_titles release];
    [_res release];
    [_showFirst release];
    [initmark release];
    [outputtitles release];
    [_names release];
    [_part_name release];
    //[_url release];
   // [_text release];
    [initkey release];
    [_indexPathArray release];
    [detail release];
    [favBiobrick release];



    [_navBar release];
    [inittype release];
    [initdesc release];
    [style release];
   // [mainscreen release];  
    //[additonalmark release];  以上两句被移到了 viewdidunload
    
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    
        
    style=[[styleSetting alloc]init];
    

   
    self.navigationItem.title = @"Detail";
    UIBarButtonItem *storeButton = [[UIBarButtonItem alloc] initWithTitle:@"Add" style:UIBarButtonSystemItemAdd target:self action:@selector(Store)];
    [self.navigationItem setRightBarButtonItems:[[NSArray alloc]initWithObjects:storeButton, nil]];
    
    
    UIImageView *_background = [style getTableImage];
    CGRect tableFrame = self.view.frame;
    _background.frame = tableFrame;
    //_background.frame = CGRectMake(0, 0, 320, 460);
    [self.view addSubview:_background];
    
    [_background release];
    

    _showFirst = [[NSArray alloc] initWithObjects: @"Name", @"Type", @"Short Description", @"Description", @"Categories", @"Notes", @"In Stock",@"Author", @"Sequence", @"Experience", @"", @"Sequence Length", @"Creation Date", nil];
    _titles = [[NSArray alloc] initWithObjects:@"part_name", @"short_desc", @"desc", @"part_type", @"author", @"categories", @"sequence", @"in_stock", @"notes", @"sequence_length", @"creation_date", nil];
     outputtitles = [[NSArray alloc] initWithObjects:@"Part name", @"Short description", @"Description", @"Part type", @"Author", @"Categories", @"Sequence", @"In stock or not", @"Notes", @"Sequence length", @"Creation date", nil];
    initmark=[[NSString alloc] initWithString:@"None"];
    [initmark retain];

    [self openSearch];
    
    [super viewDidLoad];
}

- (void) Store{
    
    alertview=[[UIAlertView alloc]initWithTitle:@"Bookmark" 
                                                     message:@"\n\n\n" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Done", nil];
    
    UITextField *promottext=[[UITextField alloc] initWithFrame:CGRectMake(20, 47.2, 250, 20)];
    promottext.backgroundColor=[UIColor clearColor];
    promottext.text=@"Create your own bookmark:";
    promottext.enabled = NO;
    promottext.textColor=[UIColor whiteColor];
    [alertview addSubview:promottext];
    
    additonalmark=[[UITextField alloc]initWithFrame:CGRectMake(20, 78, 240, 25)];
    additonalmark.backgroundColor=[UIColor whiteColor];
    [additonalmark setBorderStyle:UITextBorderStyleBezel];
    [additonalmark setPlaceholder:@"None"];
    additonalmark.delegate=self;
    additonalmark.tag=2;//  
    [alertview addSubview:additonalmark];
    [additonalmark release];  //
	
    additonalmark.keyboardType = UIKeyboardTypeAlphabet;
    [alertview show];
	[alertview release];
    [promottext release];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{

    //initmark=textField.text;
    //[initmark retain];

    [textField resignFirstResponder];
    return  YES;
}




-(BOOL)alreadyexist:(NSString*)testname
{
    NSArray *favBiobricks = [[NSArray alloc] init];
	favBiobricks = [FavBiobrick findAll];
    
    for (id biobrick in favBiobricks) {
		if ([[biobrick ID] compare:testname]==0) {
            return YES;
        } 
	}
    return NO;
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
	if (buttonIndex == 1) {
        // NSError *error;
        //initmark=self->additonalmark.text;
        //NSLog(@"error occured! error = %@",error);
       
        initmark=self->additonalmark.text;
        if (!initmark || [initmark isEqualToString:@""]) {
            initmark = @"None";
        }
        //[initmark retain];
        favBiobrick = [[FavBiobrick alloc] initWithID:detail.part_name description:inittype mark:initmark shortdesc:initdesc];
        initkey = detail.part_name;
        if ([self alreadyexist:initkey]) {
            alertView=[[UIAlertView alloc] initWithTitle:@"Alert" message:@"The biobrick already exists in the bookmark" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [alertView show];
        }
        else {
            
            [FavBiobrick createWithID:[favBiobrick ID] description:[favBiobrick Description] mark:[favBiobrick Mymark] shortdesc:[favBiobrick Shortdesc]];
        }

	}
}

- (void)loadView {
    
	CGRect tableFrame = [[UIScreen mainScreen] bounds];
    UIView *first = [[UIView alloc] initWithFrame:tableFrame];
	//UIView * first=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 600)];
	first.backgroundColor=[UIColor blackColor];
	self.view=first;
    [first release];
    

}


-(void)viewDidAppear:(BOOL)animated
{
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [_navBar release];
    [mainscreen release];
    [style release];
    [additonalmark release];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{

    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void) openSearch
{

    _text=[[NSString alloc]init];
    _text=@"<html>	<head></head><body> <p href=\"http://www.baidu.com/\"></p>";
    for (int i=0;  i < [_titles count]; i++) {
        NSString *string = [_titles objectAtIndex:i];
        NSString *resultString =[detail valueForKey:string];
        
        if (i==7) {
            if([resultString isEqualToString:@"1"])
            {
                resultString=@"In stock";
                                     }
            else {
                resultString=@"Not in stock";
            }
        }
        if (i == 6 ) {
            for (int i = 0 ; i < [resultString length] ; i = i+45 ) {
                resultString=[[[resultString substringToIndex:i] stringByAppendingString:@"\n"] stringByAppendingString:[resultString substringFromIndex:i]];
            }
        }
        
        if (i == 3 ) {
            inittype =[[NSString alloc]initWithString:resultString];
        }
        if ( i == 2 ) {
            initdesc =[[NSString alloc]initWithString:resultString];
        }
                                 
        if (i==0) {
            NSString* _prefix = [[NSString alloc] initWithString:@"http://partsregistry.org/Part:"];
            NSString* _postfix = [[NSString alloc] initWithString:@":Experience"];
            _url = [[NSString alloc] initWithString:resultString];
            _url = [_prefix stringByAppendingString:_url];
            _url = [_url stringByAppendingString:_postfix];
            [_url retain];
            NSString* _mrprefix = [[NSString alloc] initWithString:@"http://partsregistry.org/Part:"];
            _mrurl = [[NSString alloc] initWithString:resultString];
            _mrurl = [_mrprefix stringByAppendingString:_mrurl];
            [_mrurl retain];
            _text=[_text stringByAppendingFormat:@"<p>%@</p><p><font color=\"gray\">%@</font></p><p><font color=\"black\">User experience</font></p>",[outputtitles objectAtIndex:i],resultString];
            _text=[_text stringByAppendingString:@"<p>More Information in PartsRegistry</p><p>"];
        }
        else {
            _text=[_text stringByAppendingFormat:@"<p>%@</p><p><font color=\"gray\">%@</font></p>",[outputtitles objectAtIndex:i],resultString];
        }

        
    }
    _text=[_text stringByAppendingString:@"</body></html>"];
    CGRect tableFrame = self.view.frame;
    tableFrame.size.height = tableFrame.size.height - 110;
    mainscreen = [[UIWebView alloc] initWithFrame:tableFrame];
    //mainscreen=[[UIWebView alloc]initWithFrame:CGRectMake(0, 0, 320, 370)];
    mainscreen.backgroundColor=[UIColor clearColor];
    mainscreen.opaque=NO;
    UIButton *experience=[UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    [experience setFrame:CGRectMake(135, 75, 30, 30)];
    [experience addTarget:self action:@selector(gotoExperience) forControlEvents:UIControlEventTouchUpInside];
    UIButton *more=[UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    [more setFrame:CGRectMake(255, 110, 30, 30)];
    [more addTarget:self action:@selector(gotoMore) forControlEvents:UIControlEventTouchUpInside];
    [mainscreen loadHTMLString:_text baseURL:nil];
    [mainscreen.scrollView addSubview:experience];
    [mainscreen.scrollView addSubview:more];
    [self.view addSubview:mainscreen];
    [_res retain];
    [initkey retain];
    
     
     
    
                                                       

}
-(void)gotoMore
{
    
    
    NSURL *url = [[NSURL alloc] initWithString:_mrurl];
    NSLog(@"xxx %@",_mrurl);
    [ [ UIApplication sharedApplication ] openURL: url ];
    [url release];

}

-(void)gotoExperience
{
    
    NSURL *url = [[NSURL alloc] initWithString:_url];
    [ [ UIApplication sharedApplication ] openURL: url ];
    [url release];

}

@end
