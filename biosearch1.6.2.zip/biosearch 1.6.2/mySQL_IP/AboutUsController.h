//
//  AboutUsController.h
//  BioSearch
//
//  Created by panda on 12-9-29.
//
//

#import <UIKit/UIKit.h>

@interface AboutUsController : UIViewController

@end
