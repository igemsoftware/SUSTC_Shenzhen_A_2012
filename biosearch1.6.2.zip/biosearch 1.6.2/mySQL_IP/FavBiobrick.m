//
//  FavBiobrick.m
//  mySQL_IP
//
//  Created by abc on 12-7-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "FavBiobrick.h"
#import "FavDataBase.h"

@implementation FavBiobrick

+ (NSArray *) findAll{
	PLSqliteDatabase *dataBase = [FavDataBase setup];
	
	id<PLResultSet> tmp;
	tmp = [dataBase executeQuery:@"select * from FavBook"];
	NSMutableArray *favBiobricks = [[NSMutableArray alloc] init];
	while ([tmp next]) {
		NSString *ID = [tmp objectForColumn:@"ID"];
        NSString *Desciption = [tmp objectForColumn:@"Author"];
        NSString *Mark=[tmp objectForColumn:@"Publishhouse"];
        NSString *Shortdesc=[tmp objectForColumn:@"Name"];
		FavBiobrick *favbiobrick = [[FavBiobrick alloc] initWithID:ID description:Desciption mark:Mark shortdesc:Shortdesc];
		[favBiobricks addObject:favbiobrick];
		[favbiobrick release];  
	}
	[tmp close];
	
	return favBiobricks;
}


+ (int) createWithID:(NSString *) ID description:(NSString *)Description mark:(NSString *)Mymark shortdesc:(NSString *)Shortdesc
{
	PLSqliteDatabase *dataBase = [FavDataBase setup];
    
    BOOL bResult = [dataBase executeUpdate: @"insert into FavBook (ID , Author, Publishhouse, Name) values (? , ? , ?, ?)", ID, Description,Mymark,Shortdesc];	
	return bResult;
}

+ (int) delete:(NSString *) ID{
	PLSqliteDatabase *favDataBase = [FavDataBase setup];
	
	BOOL bResult = [favDataBase executeUpdate:@"DELETE FROM FavBook WHERE ID = ?",
					ID];
	
	return bResult;
}

- (id) initWithID:(NSString *) ID description:(NSString *)Description mark:(NSString *)Mymark shortdesc:(NSString *)Shortdesc
{
	if (self = [super init]) {
		_id = [ID retain];
		_desciption = [Description retain];
        _mymark=[Mymark retain];
        _shortdesc=[Shortdesc retain];
	}
	return self;
}


- (NSString *) ID{
	return _id;
}

- (NSString *) Description{
 return _desciption;
 }

- (NSString *) Mymark{
    return _mymark;
}

- (NSString *) Shortdesc{
return _shortdesc;
}

 
@end