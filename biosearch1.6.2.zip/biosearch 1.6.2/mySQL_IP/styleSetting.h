//
//  styleSetting.h
//  mySQL_IP
//
//  Created by abc on 12-8-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface styleSetting : UIViewController
{
    UIColor *cellBackColour;
    UIColor *cellTextColour;
    UIColor *tableSeperatorColour;
    UIImageView *tableImage;
    UITableViewCellSelectionStyle cellSelected;
}

@property(nonatomic,retain) UIColor *cellBackColour;
@property(nonatomic,retain) UIColor *cellTextColour;
@property(nonatomic,retain) UIColor *tableSeperatorColour;
@property(nonatomic,retain) UIImageView *tableImage;
@property UITableViewCellSelectionStyle cellSelected;

-(void) showNetworkError;
-(UIColor*)getCellBackColour;
-(UIColor*)getCellTextColour;
-(UIColor*)getTableSeperatorColour;
-(UIImageView*)getTableImage;
-(UITableViewCellSelectionStyle)getCellSelectedStyle;
- (BOOL) connectedToNetwork;
@end
