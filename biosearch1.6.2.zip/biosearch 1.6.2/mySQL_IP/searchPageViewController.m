//
//  searchPageViewController.m
//  mySQL_IP
//
//  Created by Mubing Zhou on 12-7-24.
//  Copyright (c) 2012年 SUSTC. All rights reserved.
//

#import "searchPageViewController.h"

@interface searchPageViewController ()

@end

@implementation searchPageViewController
@synthesize _part_name;
@synthesize _description;
@synthesize _author;
@synthesize _type;
//@synthesize _length1;
//@synthesize _length2;
@synthesize _status;
@synthesize _chassis;
@synthesize _endDate;
@synthesize _startDate;
@synthesize  _searchBarPlayContoller;

- (void)dealloc
{
    [_resultArray release];
    [_temp_resultArray release];
    [_part_name release];
    [_description release];
    [_author release];
    [_type release];
    //[_length1 release];
    //[_length2 release];
    [_status release];
    [_chassis release];
    [_endDate release];
    [_startDate release];
    [style release];
    [_searchBarPlayContoller release];
    
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSearch target:self action:@selector(searchBar:)];
    self.navigationItem.rightBarButtonItem = rightBarButton;
    
    style=[[styleSetting alloc] init];
    UIImageView *_background = [style getTableImage];//[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"羊皮纸.png"]];
     _background.frame = CGRectMake(0, 0, 320, 460);
    
    
    _AND_flag = 0;
    
    _resultArray = [NSMutableArray array];
    _resultArray = nil;
    
    _temp_resultArray  = [NSMutableArray array];

    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, 320, 45)];
    [_searchBar setScopeButtonTitles:[NSArray arrayWithObjects:@"df",nil]];
    _searchBar.delegate = self;
   // [_searchBar setTintColor:[UIColor blackColor]];
   // _searchBar.backgroundColor=[UIColor blackColor];
    [_searchBar setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [_searchBar sizeToFit];
    
    [self search];
    [_resultArray retain];

    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, 370) style:UITableViewStylePlain];
    [_tableView setContentOffset:CGPointMake(0, 45)];
    _tableView.backgroundColor = [UIColor clearColor];
   // _tableView.separatorColor = [style getTableSeperatorColour];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableHeaderView = _searchBar;
   // _tableView.backgroundView = _background;
    [self.view addSubview:_tableView];
    
    _searchBarPlayContoller = [[UISearchDisplayController alloc] initWithSearchBar:_searchBar contentsController:self];
	[self set_searchBarPlayContoller:_searchBarPlayContoller];
	[_searchBarPlayContoller setDelegate:self];
	[_searchBarPlayContoller setSearchResultsDataSource:self];
    
	//[_searchBar release];
    
    
    if ([style connectedToNetwork]==NO) 
    {
        [self.view addSubview:_background];
        [style showNetworkError];
    }
    [_background release];
    
}
-(void)searchBar:(id)sender
{
    _tableView.frame = CGRectMake(0, 0, 320, 430);
	[_searchBarPlayContoller setActive:YES animated:YES];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    [_tableView release];
    [_searchBar release];
   // [style release];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void) search
{
    no_result_flag = 0;
    NSString* _sentence = @"select part_name,status,in_stock,short_desc from parts4 where ";
       if (_part_name != nil && [_part_name length] != 0) 
    {
        if (_AND_flag != 0) {
            _sentence = [_sentence stringByAppendingString:@"AND "];
        }
        _part_name = [self decorateString:_part_name];
        _sentence = [_sentence stringByAppendingString:@"part_name like "];
        _sentence = [_sentence stringByAppendingString:_part_name];
        _AND_flag++;
        
    }
    if (_description != nil && [_description length] != 0) 
    {
        if (_AND_flag != 0) {
            _sentence = [_sentence stringByAppendingString:@"AND "];
            
        }
        _description = [self decorateString:_description];
        _sentence = [_sentence stringByAppendingString:@"description like "];
        _sentence = [_sentence stringByAppendingString:_description];

        
        _AND_flag++;
    }
    if (_author != nil && [_author length] != 0) 
    {
        if (_AND_flag != 0) {
            _sentence = [_sentence stringByAppendingString:@"AND "];
            
        }
        _author = [self decorateString:_author];
        _sentence = [_sentence stringByAppendingString:@"author like "];
        _sentence = [_sentence stringByAppendingString:_author];
 
        
        _AND_flag++;
    }
    if (_type != nil && [_type length] != 0 && ![_type isEqualToString:@"None"] && ![_type isEqualToString:@"All"]) 
    {
        if (_AND_flag != 0) {
            _sentence = [_sentence stringByAppendingString:@"AND "];
            
        }
        _type = [self decorateString:_type];
        _sentence = [_sentence stringByAppendingString:@"part_type like "];
        _sentence = [_sentence stringByAppendingString:_type];
        
        _sentence = [_sentence stringByAppendingString:@"OR categories like "];
        _sentence = [_sentence stringByAppendingString:_type];

        _AND_flag++;
    }
    if (_chassis != nil && [_chassis length] != 0 &&![_chassis isEqualToString:@"None"] &&![_chassis isEqualToString:@"All"]) 
    {
        if (_AND_flag != 0) {
            _sentence = [_sentence stringByAppendingString:@"AND "];
            
        }
        _chassis = [self decorateString:_chassis];
        _sentence = [_sentence stringByAppendingString:@"categories like "];
        _sentence = [_sentence stringByAppendingString:_chassis];
     
        _AND_flag++;
    }
    if (_status != nil && [_status length] != 0 && ![_status isEqualToString:@"None"] && ![_status isEqualToString:@"All"]) 
    {
        if (_AND_flag != 0) {
            _sentence = [_sentence stringByAppendingString:@"AND "];
            
        }
        _status = [self decorateString:_status];
        _sentence = [_sentence stringByAppendingString:@"status like "];
        _sentence = [_sentence stringByAppendingString:_status];
      
        _AND_flag++;
    }
    
    
    if ([_startDate length] != 0 && [_endDate length] != 0 && _startDate != nil && _endDate != nil) {
        if (_AND_flag != 0) {
            _sentence = [_sentence stringByAppendingString:@"AND "];

        }
        _startDate = [NSString stringWithFormat:@"'%@'", _startDate];
        _endDate = [NSString stringWithFormat:@"'%@'", _endDate];
        _sentence = [_sentence stringByAppendingFormat:@"creation_date BETWEEN %@ AND %@ ",_startDate,_endDate];
      
        _AND_flag++;
    }
    
    _sentence = [_sentence stringByAppendingString:@" order by status asc, in_stock, creation_date desc "];
     
    
    if (_AND_flag != 0) {
        
        MysqlManager* mysqlManager = [[MysqlManager alloc] init];
        
        if ([[NSUserDefaults standardUserDefaults] integerForKey:@"ip"]==0) {
            [mysqlManager connectHost:@"76.73.125.43" connectUser:@"igem03" connectPassword:@"okjbvv6237" connectName:@"igem03"];
           
        }
        else if([[NSUserDefaults standardUserDefaults] integerForKey:@"ip"]==1){
            [mysqlManager connectHost:@"221.231.138.29" connectUser:@"igem02" connectPassword:@"okjbvv6237" connectName:@"igem02"];

        }
        else {
            [mysqlManager connectHost:@"203.124.13.83" connectUser:@"igem01" connectPassword:@"okjbvv6237" connectName:@"igem01"];
        }
        NSMutableArray *res1 = [NSMutableArray array];
        res1 = [mysqlManager query:_sentence];
      
        if ([res1 count] == 0) 
        {
            res1= [NSArray arrayWithObject:[NSArray arrayWithObject:@"No results"]];
            no_result_flag = 1;
        }
        else
        {
        res1 = [self processResult:res1];
        }
        _resultArray = res1;

        _AND_flag = 0;
       
        
        
        [_resultArray retain];
     
        [mysqlManager disconnect];
        [mysqlManager release];

        [res1 release];

    }
    else {
        _resultArray = [NSArray arrayWithObject:[NSArray arrayWithObject:@"No results"]];
        no_result_flag = 1;
    }
    
    _temp_resultArray = [NSMutableArray arrayWithArray:_resultArray];
    [_temp_resultArray retain];
}

-(NSString*) decorateString:(NSString*) input
{
    NSString* _tempPrefix = @"'%";
    NSString* _tempPostfix = @"%' ";
    input = [_tempPrefix stringByAppendingString:input];
    input = [input stringByAppendingString:_tempPostfix];
    
    [_tempPrefix release];
    [_tempPostfix release];
    
    return input;
}
-(NSMutableArray*) processResult:(NSMutableArray *)resultArray
{
    NSMutableIndexSet* _remove_index_set = [[NSMutableIndexSet alloc] init];
    NSMutableArray* _ava_in = [NSMutableArray array];
    NSMutableArray* _ava_not_in = [NSMutableArray array];
    NSMutableArray* _not_ava_in = [NSMutableArray array];
    NSMutableArray* _not_ava_not_in = [NSMutableArray array];
    
    for (int i = 0; i < [resultArray count]; i++)
    {
        if ([[NSString stringWithFormat:@"%@",[[resultArray objectAtIndex:i] objectAtIndex:1]] isEqualToString:@"Available"] && [[NSString stringWithFormat:@"%@",[[resultArray objectAtIndex:i] objectAtIndex:2]] isEqualToString:@"1"])
        {
            [_ava_in addObject:[resultArray objectAtIndex:i]];
            [_remove_index_set addIndex:i];
        }
    }
    [resultArray removeObjectsAtIndexes:_remove_index_set];

    [_remove_index_set removeAllIndexes];
    
    for (int i = 0; i < [resultArray count]; i++)
    {
        if ([[NSString stringWithFormat:@"%@",[[resultArray objectAtIndex:i] objectAtIndex:1]] isEqualToString:@"Available"] && ![[NSString stringWithFormat:@"%@",[[resultArray objectAtIndex:i] objectAtIndex:2]] isEqualToString:@"1"])
        {
            [_ava_not_in addObject:[resultArray objectAtIndex:i]];
            [_remove_index_set addIndex:i];
        }
    }
    [resultArray removeObjectsAtIndexes:_remove_index_set];

    [_remove_index_set removeAllIndexes];
    
    for (int i = 0; i < [resultArray count]; i++)
    {
        if (![[[resultArray objectAtIndex:i] objectAtIndex:1] isEqualToString:@"Available"] && [[[resultArray objectAtIndex:i] objectAtIndex:2] isEqualToString:@"1"])
        {
            [_not_ava_in addObject:[resultArray objectAtIndex:i]];
            [_remove_index_set addIndex:i];
        }
    }
    [resultArray removeObjectsAtIndexes:_remove_index_set];

    _not_ava_not_in = resultArray;

    _ava_in = [self lengthDateInOrder:_ava_in];
    _ava_not_in = [self lengthDateInOrder:_ava_not_in];
    _not_ava_in = [self lengthDateInOrder:_not_ava_in];
    _not_ava_not_in = [self lengthDateInOrder:_not_ava_not_in];

    NSMutableArray* _return = [NSMutableArray arrayWithArray:_ava_in];
    for (int i = 0; i < [_ava_not_in count]; i++)
    {
        [_return addObject:[_ava_not_in objectAtIndex:i]];
    }
    for (int i = 0; i < [_not_ava_in count]; i++)
    {
        [_return addObject:[_not_ava_in objectAtIndex:i]];
    }
    for (int i = 0; i < [_not_ava_not_in count]; i++)
    {
        [_return addObject:[_not_ava_not_in objectAtIndex:i]];
    }
 
    [_remove_index_set release];
   // [_ava_in release];
     return _return;
}

-(NSMutableArray*) lengthDateInOrder:(NSMutableArray*) input
{

    NSMutableArray* _return = [NSMutableArray array];
    int max_length = 0;
       for (int i = 0; i < [input count]; i++)
    {
        if ([[[input objectAtIndex:i] objectAtIndex:3] length] > max_length)
        {
            max_length = [[[input objectAtIndex:i] objectAtIndex:3] length] ;
        }
    }
    for (int i = max_length; i > 0; i--)
    {
        for (int j = 0; j < [input count]; j++)
        {
            if ([[[input objectAtIndex:j] objectAtIndex:3] length] == i)
            {
                [_return addObject:[input objectAtIndex:j]];
            }
        }
    }
    

    return _return;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if ([_resultArray count]==1) {
        [_tableView setSeparatorColor:[UIColor clearColor]];
    }
    
    return [_resultArray count];
}




-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    tableView.backgroundView =  [style getTableImage];
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // Configure the cell...
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.selectionStyle = [style getCellSelectedStyle];
    }//当cell为空的时候，创建一个cell

    
    if(indexPath.row == 0)
    {
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.detailTextLabel.textColor = [UIColor grayColor];
        if (![[[_resultArray objectAtIndex:indexPath.section ] objectAtIndex:0] isEqualToString:@"No results"]) 
        {
            NSString* _temp_name = [NSString stringWithFormat:@"%@", [[_resultArray objectAtIndex:indexPath.section ] objectAtIndex:0]];
            NSString* _temp_status = [NSString stringWithFormat:@"%@", [[_resultArray objectAtIndex:indexPath.section ] objectAtIndex:1]];
            //_temp_status = [_temp_status substringWithRange:NSMakeRange(0, 1)];
            NSString* _temp_in_stock = [NSString stringWithFormat:@"%@", [[_resultArray objectAtIndex:indexPath.section ] objectAtIndex:2]];
            if ([_temp_in_stock isEqualToString:@"1"] ) {
                _temp_in_stock = @"In stock";
            }
            else {
                _temp_in_stock = @"Not in stock";
            }
           
            
            NSString* _temp_short_desc= [NSString stringWithFormat:@"%@", [[_resultArray objectAtIndex:indexPath.section ] objectAtIndex:3]];
            [cell.textLabel setTextColor:[UIColor brownColor]];
            cell.textLabel.text = [NSString stringWithFormat:@"%@",_temp_name] ;
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%@,  %@\n%@" ,_temp_status,_temp_in_stock,_temp_short_desc];
          //  cell.detailTextLabel.text = [NSString stringWithFormat:@"\n%@",_temp_short_desc];
            [cell.detailTextLabel setNumberOfLines:4];
            [cell.detailTextLabel setTextColor:[UIColor darkGrayColor]];
        }
        else {
            cell.textLabel.textAlignment=UITextAlignmentCenter;
            cell.textLabel.text = [NSString stringWithFormat:@"                     %@ ", [[_resultArray objectAtIndex:indexPath.section ] objectAtIndex:0]];
            [cell setAccessoryType:UITableViewCellAccessoryNone];
           
        }
        
    }

    cell.textLabel.textColor = [style getCellTextColour];
    cell.backgroundColor = [style getCellBackColour];
    
    
    return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (![[[_resultArray objectAtIndex:indexPath.section ] objectAtIndex:0] isEqualToString:@"No results"]) {
         return 120;
    }
    else {
        return 380;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{ 
    
    UITableViewCell *cell = (UITableViewCell*) [tableView cellForRowAtIndexPath:indexPath];
    cell.selected=NO;
    
    MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    
    HUD.delegate = self;
    HUD.labelText = @"Loading";
    
    [HUD show:YES];
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 0.01 * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        // Do something...
        if (![[[_resultArray objectAtIndex:indexPath.section ] objectAtIndex:0] isEqualToString:@"No results"])
        {
            NSString* _temp = [NSString stringWithFormat:@"%@", [[_resultArray objectAtIndex:indexPath.section ] objectAtIndex:0]];
            detailpage* _detailPage = [[detailpage alloc] init];
            
            _detailPage._part_name = _temp;
            
            [self.navigationController pushViewController:_detailPage animated:YES];
            [_detailPage release];
            [_temp release];
        }
        
        [HUD hide:YES];
    });

    
    
}

-(void)searchInSearchBar:(NSString *)key
{
    if (key != nil && [key length] != 0)// && [_resultArray count] != 0)
    {
        if ([_resultArray count] != 0) {
            [_resultArray removeAllObjects];
        }
        
        NSMutableArray* _id_doc = [[NSMutableArray alloc] init];
        
        for (int i = 0; i < [_temp_resultArray count]; i++)
        {
            
            NSRange range = [[[_temp_resultArray objectAtIndex:i] objectAtIndex:0] rangeOfString:key options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch)];
            NSRange range1 = [[[_temp_resultArray objectAtIndex:i] objectAtIndex:1] rangeOfString:key options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch)];
            NSRange range2 = [[[_temp_resultArray objectAtIndex:i] objectAtIndex:2] rangeOfString:key options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch)];
            NSRange range3 = [[[_temp_resultArray objectAtIndex:i] objectAtIndex:3] rangeOfString:key options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch)];
            
            if (range1.length != 0 || range2.length != 0 || range3.length != 0 || range.length != 0)
            {
                [_id_doc addObject:[NSString stringWithFormat:@"%d",i]];
                [_id_doc removeObjectIdenticalTo:[NSString stringWithFormat:@"%d",i]];
            }
        }
        NSLog(@"id_doc = %@",_id_doc);
        
        for (int i = 0; i < [_id_doc count]; i++)
        {
            int index = [[_id_doc objectAtIndex:i] intValue];
            
            id ob = [_temp_resultArray objectAtIndex:index];
            
            [_resultArray addObject:ob];
            NSLog(@"%i",i);
            
        }
        
        [_id_doc release];
        
        
    } 
    [_tableView reloadData];
}

#pragma mark UISearchDisplayController Delegate Methods

- (void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{
	/*
	 Hide the search bar
	 */
        if (![[[_temp_resultArray objectAtIndex:0] objectAtIndex:0] isEqualToString:@"No results"])
        {
            [_resultArray removeAllObjects];
            [_resultArray addObjectsFromArray:_temp_resultArray];
        }
    
    if ([_resultArray count] != 0 && _resultArray != nil) {
        [_resultArray removeAllObjects];
        [_resultArray addObjectsFromArray:_temp_resultArray];
    }
    if (_resultArray == nil) {
        NSArray* temp = [[NSArray alloc] initWithObjects:@"No results", nil];
        _resultArray  = [[NSMutableArray alloc] initWithObjects:temp, nil];
        [temp release];
    }
    
    [_tableView reloadData];
    _tableView.frame = CGRectMake(0, 0, 320, 370);
	[_tableView setContentOffset:CGPointMake(0, 45) animated:YES];
    
    
}

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    
    if (no_result_flag == 1) {
        _resultArray = nil;
    }
    else {
        [self searchInSearchBar:searchText];
    }
    
}

- (void)searchDisplayControllerDidBeginSearch:(UISearchDisplayController *)controller
{
    
	[self.searchDisplayController.searchResultsTableView setDelegate:self];

}



@end
