//
//  webpage.h
//  mySQL_IP
//
//  Created by apple on 12-7-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "styleSetting.h"
@interface webpage : UIViewController<UITextViewDelegate>
{
    UIWebView *content;
    UIImageView *background;
    NSString *searchkey;
    styleSetting *style;
}
@property(nonatomic,retain) UIWebView *content;
@property(nonatomic,retain) UIImageView *background;
@property(nonatomic,retain) NSString *searchkey;
-(void)searchwebpage:(NSString *)searchkey;


@end
