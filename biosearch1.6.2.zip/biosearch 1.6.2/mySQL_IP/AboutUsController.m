//
//  AboutUsController.m
//  BioSearch
//
//  Created by panda on 12-9-29.
//
//

#import "AboutUsController.h"
#import "styleSetting.h"
@interface AboutUsController ()
@property (retain, nonatomic) IBOutlet UITextView *myTextField;
@property (strong,nonatomic)styleSetting *style;
@end

@implementation AboutUsController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
       // self.style = [[styleSetting alloc]init];
        //self.view.backgroundColor = [self.style getCellBackColour];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    self.myTextField.text = @"We are 2012 iGEM  competition team SUSTC Shenzhen A.                                                       We are sophomore at South University of Science and Technology of China, located at Shenzhen, China.                                            This program is developed by Qijia Cheng, Zili Fan, Jingyao Guo, Yiqi Jiang, Chenchen Lv, Deng Pan, Yidan Pan, Xiao Tong, Xin Yang, Junqiu Zhang, Yujun Zhao, Mubing Zhou.\nThis program is developed under the instruction of Prof. Jiankui He.                                                   Please visit our wiki for more information:                                            http://2012.igem.org/Team:SUSTC-Shenzhen-A \nCopyright @ South University of Science and Technology of China";
    NSLog(@"mytext = %@",self.myTextField.text);
    self.myTextField.dataDetectorTypes = UIDataDetectorTypeLink;
    self.myTextField.backgroundColor = [UIColor clearColor];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)dealloc {
    [_myTextField release];
    [_style release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setMyTextField:nil];
    [self setStyle:nil];
    [super viewDidUnload];
}
@end
