//
//  mySQL_IPAppDelegate.h
//  mySQL_IP
//
//  Created by  apple on 11-7-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "TabBarController.h"


@interface mySQL_IPAppDelegate : NSObject <UIApplicationDelegate,UITabBarControllerDelegate> {
    TabBarController *_main;
    //NSManagedObjectContext *managedObjectContext;
    //NSManagedObjectModel *managedObjectModel;
    //NSPersistentStoreCoordinator *persistentStoreCoordinator;


}




@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (strong,nonatomic) NSURL *storeURL;
@property(strong,nonatomic) NSString *path;
- (void)saveContext;
-(void)createEditableCopyOfDatabaseIfNeeded;

@end
