//
//  TabBarController.m
//  mySQL_IP
//
//  Created by abc on 12-8-13.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TabBarController.h"
#import "Catagory.h"
#import "help.h"
#import "history.h"
#import "FirstViewController.h"
//#import "Userdefaultsetting.h"
@interface TabBarController ()

@end

@implementation TabBarController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    //the following part is an update checker
    /*
    NSString *version = @"";
    NSURL *url = [NSURL URLWithString:@"http://itunes.apple.com/lookup?id=284417350"];   //this part "id=284417350" should be replaced by "id='our app id'"
    ASIHTTPRequest *versionRequest = [ASIHTTPRequest requestWithURL:url];
    [versionRequest setRequestMethod:@"GET"];
    [versionRequest setDelegate:self];
    [versionRequest setTimeOutSeconds:150];
    [versionRequest addRequestHeader:@"Content-Type" value:@"application/json"];
    [versionRequest startSynchronous];
    
    //Response string of our REST call
    NSString* jsonResponseString = [versionRequest responseString];
    
    NSDictionary *loginAuthenticationResponse = [jsonResponseString objectFromJSONString];
    
    NSArray *configData = [loginAuthenticationResponse valueForKey:@"results"];
    
    for (id config in configData)
    {
        version = [config valueForKey:@"version"];
    }
    //Check your version with the version in app store
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"Info" ofType:@"plist"];
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    
    
    if (![version isEqualToString:[data objectForKey:@"Version"]])
    {
        UIAlertView *createUserResponseAlert = [[UIAlertView alloc] initWithTitle:@"New Version!!" message: @"A new version of app is available to download" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles: @"Download", nil];
        [createUserResponseAlert show];   
        [createUserResponseAlert release];  
    }
    
*/

}

- (void)loadView {
	
	UIView * first=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
	first.backgroundColor=[UIColor whiteColor];
	self.view=first;
    
    [self initwithview];
}

- (void)alertView:(UIAlertView *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    // the user clicked one of the OK/Cancel buttons
    if (buttonIndex == 1)
    {
        NSString *iTunesLink = @"itms-apps://phobos.apple.com/WebObjects/MZStore.woa/wa/viewSoftwareUpdate?id=<appid>&mt=8";
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:iTunesLink]];
    }
}

-(void)initwithview
{
   
       // [_main.view removeFromSuperview];
        
    tab1=[[UITabBarController alloc]init];
        
    Catagory *_catogery=[[Catagory alloc]init];
    UINavigationController *nav1=[[UINavigationController alloc]initWithRootViewController:_catogery];
    _catogery.tabBarItem=[[UITabBarItem alloc]initWithTitle:@"catalog" image:[UIImage imageNamed: @"category_icon.png"] tag:1];
    nav1.navigationBar.barStyle = UIBarStyleBlackOpaque;
        
    FirstViewController *_search=[[FirstViewController alloc]init];
    UINavigationController *nav2=[[UINavigationController alloc]initWithRootViewController:_search];
    _search.tabBarItem=[[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemSearch tag:0];
    nav2.navigationBar.barStyle = UIBarStyleBlackOpaque;
        
    history *_history=[[history alloc]init];
    UINavigationController *nav3=[[UINavigationController alloc]initWithRootViewController:_history];
    _history.tabBarItem=[[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemFavorites tag:2];
    nav3.navigationBar.barStyle = UIBarStyleBlackOpaque;
        
    help *_help=[[help alloc]init];
        
    UINavigationController *nav4=[[UINavigationController alloc]initWithRootViewController:_help];
    _help.tabBarItem=[[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemMore tag:3];
    nav4.navigationBar.barStyle = UIBarStyleBlackOpaque;
    
    //Userdefaultsetting *_userdefault=[[Userdefaultsetting alloc]init];
    //UINavigationController *nav5=[[UINavigationController alloc]initWithRootViewController:_userdefault];
    //_userdefault.tabBarItem=[[UITabBarItem alloc]initWithTitle:@"Setting" image:[UIImage imageNamed:@"setting.png"] tag:4];

    
    tab1.viewControllers=[[NSArray alloc]initWithObjects:nav2,nav1,nav3,nav4, nil];
    tab1.view.frame=CGRectMake(0, 0, 320, 480);
    

      
    [self.view addSubview:tab1.view];
    [nav1 release];
    [_catogery release];
    [nav2 release];
    [_help release];
    [nav3 release];
    [_search release];
    [nav4 release];
    [_history release];
    
    
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    [tab1 release];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
