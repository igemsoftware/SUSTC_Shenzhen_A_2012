Installation and operation

Decompress the zip file

Run  BioSearch.xcodeproj


Soft introduction

Biosearch
The era of Partsregistry on mobile phone has arrived! With BioSearch on your iPhone, you can now check biobricks and partsregistry in the seminar room; You can design your genetic circuits when you are waiting for a bus! BioSearch is fully interacting with Partsregistry( http://partsregistry.org ) and has all parts information of Partsregistry database with enhanced user-friendly interface.
BioSearch has a powerful search engine. Users can search parts and devices by type, by category, by keywords, etc. Our online survey shows that BioSearch has major improvement in search result ranking. In addition, our iPhone App has new functions including sharing, rating, adding bookmarks and downloading to local system. These new functions shall promote the commuting and sharing between synthetic biologists. The BioSearch is going to be available on Apple Store and is free to use.


Operating environment\
OS: Mac OS\
Essential software: Xcode

Contract us

Official Website:  http://2012.igem.org/Team:SUSTC-Shenzhen-A

E.mail:  2012iGemSustcShenzhenA@gmail.com